


<!DOCTYPE html>
<html lang="en">
<head>
	<link href="css/columns.css" rel="stylesheet" type="text/css">
    <link href="css/homepage.css" rel="stylesheet" type="text/css">


    <style>
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
        .column {
            float: left;
            width: 100%;


        }
        .column1 {
            float: left;
            width: 30%;
            padding-right:2px;
        }


    </style>
</head>

<body >

<?php
include "./php/header.php";
include "./php/menu.php";
?>
<!-- Side navigation -->

<div class="content">

    <div class="row">



        <div class="column1">
            <div class="panel panel-info" style="width:auto">

                <div class="panel-heading">
                    <a href="http://localhost:8080/eudoxus/php/anakoinwseis.php" class=”btn”>Ανακοινώσεις</a>
                </div>
                <div class="panel-body">


                    <div class="clDiv200">09/01/2019 <a href="https://eudoxus.gr/files/Nea_Paratasi_Xeimerinou_2018-19.pdf">Νέα Προθεσμία δηλώσεων συγγραμμάτων </a></div>



                    <div class="clDiv200">20/12/2018 <a href="https://eudoxus.gr/files/Paratasi_Xeimerinou_2018-19.pdf"> Προθεσμία δηλώσεων συγγραμμάτων </a></div>



                    <div class="clDiv200">1/11/2018 <a href="https://support.mozilla.org/en-US/kb/install-older-version-of-firefox#w_i-still-want-to-downgrade-ae-where-can-i-get-the-previous-version">Πρόβλημα λειτουργίας της εφαρμογής εκδοτών μέσω Mozilla Firefox </a></div>


                    <a href="http://localhost:8080/eudoxus/php/anakoinwseis.php" class=”btn”>>></a>

                </div>
            </div>

        </div>
        <div class="column">
            <h2 style="color:darkblue">Καλώς ήρθατε στον Εύδοξο.</h2>
           <p style="font-size:120%"> Πρόκειται για μία πρωτοποριακή υπηρεσία για την άμεση και
        ολοκληρωμένη παροχή των Συγγραμμάτων των προπτυχιακών φοιτητών
        των Πανεπιστημίων, των Τεχνολογικών Εκπαιδευτικών Ιδρυμάτων (Τ.Ε.Ι.)
        και των Ανώτατων Εκκλησιαστικών Ακαδημιών (Α.Ε.Α.) της επικράτειας καθώς και του Ελληνικού
               Ανοιχτού Πανεπιστημίου (Ε.Α.Π.).</p>
        </div>
        <div class="column" style="width:470px;">
            <header id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                    <li data-target="#myCarousel" data-slide-to="2"></li>
                    <li data-target="#myCarousel" data-slide-to="3"></li>
                    <li data-target="#myCarousel" data-slide-to="4"></li>
                    <li data-target="#myCarousel" data-slide-to="5"></li>
                </ol>

                <!-- Wrapper for Slides -->
                <div class="carousel-inner" role="listbox" >

                    <div class="item active">
                        <!-- Set the first background image using inline CSS below. -->
                        <div class="slider-size" style="background-color: white">
                            <img src="images/book.jpg" class="img-responsive first-slide" alt="First slide" style="width:100%;height:100%;" />
                        </div>

                        <div class="container">
                            <div class="carousel-caption" >
                                <div class="caption-one" >
                                    <h1 style="color: white;
                                        text-shadow:
                                        -1px -1px 0 #000,
                                        1px -1px 0 #000,
                                        -1px 1px 0 #000,
                                        1px 1px 0 #000;font-family: 'Arial Rounded MT Bold'">Φοιτητές. </h1>
                                    <br>
                                    <a href="./php/student.php" class="btn btn-primary btn-lg hvr-underline-from-left" role="button" style="color:blanchedalmond;font-family: 'Arial Rounded MT Bold'">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <!-- Set the first background image using inline CSS below. -->
                        <div class="slider-size"  style="background-color: white">
                            <img src="images/p.png" class="img-responsive second-slide" alt="Second slide" style="width:100%;height:100%;"   />
                        </div>


                        <div class="container">
                            <div class="carousel-caption">
                                <div class="caption-two">
                                    <h1 style="color: white;
                                        text-shadow:
                                        -1px -1px 0 #000,
                                        1px -1px 0 #000,
                                        -1px 1px 0 #000,
                                        1px 1px 0 #000;font-family: 'Arial Rounded MT Bold'">Εκδότες.</h1>
                                    <a href="./php/publisher.php" class="btn btn-lg btn-primary hvr-underline-from-left"  role="button" style="color:blanchedalmond;font-family: 'Arial Rounded MT Bold'">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <!-- Set the first background image using inline CSS below. -->
                        <div class="slider-size"  style="background-color: white">
                            <img src="images/secr.jpg" class="img-responsive third-slide" alt="Third slide"   style="width:100%;height:100%;" />
                        </div>


                        <div class="container">
                            <div class="carousel-caption">
                                <div class="caption-three">
                                    <h1 style="color: white;
                                            text-shadow:
                                            -1px -1px 0 #000,
                                                 1px -1px 0 #000,
                                                 -1px 1px 0 #000,
                                                1px 1px 0 #000;font-family: 'Arial Rounded MT Bold'">Γραμματείες.</h1>
                                    <a href="./php/secretaries.php" class="btn btn-lg btn-primary hvr-underline-from-left"  role="button" style="color:blanchedalmond;font-family: 'Arial Rounded MT Bold'">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <!-- Set the first background image using inline CSS below. -->
                        <div class="slider-size"  style="background-color: white">
                            <img src="images/diathetes.jpg" class="img-responsive third-slide" alt="Fourth slide" style="width:100%;height:100%;"  />
                        </div>


                        <div class="container">
                            <div class="carousel-caption">
                                <div class="caption-four">
                                    <h1 style="color: white;
                                        text-shadow:
                                        -1px -1px 0 #000,
                                        1px -1px 0 #000,
                                        -1px 1px 0 #000,
                                        1px 1px 0 #000;font-family: 'Arial Rounded MT Bold'">Διαθέτες.</h1>
                                    <a href="./php/diathetes.php" class="btn btn-lg btn-primary hvr-underline-from-left"  role="button" style="color:blanchedalmond;font-family: 'Arial Rounded MT Bold'">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <!-- Set the first background image using inline CSS below. -->
                        <div class="slider-size"  style="background-color: white">
                            <img src="images/library.jpg" class="img-responsive third-slide" alt="Fifth slide" style="width:100%;height:100%;"  />
                        </div>


                        <div class="container">
                            <div class="carousel-caption">
                                <div class="caption-five">
                                    <h1 style="color: white;
                                        text-shadow:
                                        -1px -1px 0 #000,
                                        1px -1px 0 #000,
                                        -1px 1px 0 #000,
                                        1px 1px 0 #000;font-family: 'Arial Rounded MT Bold'">Βιβλιοθήκες.</h1>
                                    <a href="./php/libraries.php" class="btn btn-lg btn-primary hvr-underline-from-left"  role="button" style="color:blanchedalmond;font-family: 'Arial Rounded MT Bold'">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <!-- Set the first background image using inline CSS below. -->
                        <div class="slider-size"  style="background-color: white">
                            <img src="images/distribution.jpg" class="img-responsive third-slide" alt="Sixth slide" style="width:100%;height:100%;"   />
                        </div>


                        <div class="container">
                            <div class="carousel-caption">
                                <div class="caption-five">
                                    <h1 style="color: white;
                                        text-shadow:
                                        -1px -1px 0 #000,
                                        1px -1px 0 #000,
                                        -1px 1px 0 #000,
                                        1px 1px 0 #000;font-family: 'Arial Rounded MT Bold'">Σημεία Διανομής.</h1>
                                    <a href="./php/distribution.php" class="btn btn-lg btn-primary hvr-underline-from-left"  role="button" style="color:blanchedalmond;font-family: 'Arial Rounded MT Bold'">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </header>
        </div>
    </div>


</div>

</body>
</html>
