<!DOCTYPE html>
<html lang="en">
<head>
    <title>Eudoxus</title>
    <meta charset="utf-8">
    <link href="http://localhost:8080/eudoxus/css/menu.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <script src="http://osvaldas.info/examples/main.js"></script>

    <script src="http://osvaldas.info/examples/drop-down-navigation-touch-friendly-and-responsive/doubletaptogo.js"></script>

    <script>
        $( function()
        {
            $( '#nav li:has(ul)' ).doubleTapToGo();
        });
    </script>
    <style>
        #nav > ul > li {
            width: 15%;
            height: 100%;
            float: left;
        }
        input[type=text] {
            width: 100%;
            border: 2px solid  white;
            font-size: 16px;
            background: white;
            padding: 5px 10px;
            border: 2px solid #b3d7ff;
        }

        input[type=text]:focus {
            width: 100%;
        }
    </style>
</head>
<body >

<div class="content">
    <nav id="nav" role="navigation"> <a href="#nav" title="Show navigation">Show navigation</a> <a href="#" title="Hide navigation">Hide navigation</a>
        <ul class="clearfix">

            <li><a class="nav-link" href="http://localhost:8080/eudoxus/php/anakoinwseis.php" >Νέα-Ανακοινώσεις</a></li>
            <li><a class="nav-link" href="http://localhost:8080/eudoxus/php/useful.php" >Χρήσιμα</a></li>
            <li><a class="nav-link"  href="http://localhost:8080/eudoxus/php/helpdesk.php"  >Βοήθεια</a></li>
            <li  style="z-index:1000;"> <a href="#">Ομάδες<span></span></a>
                <ul>
                    <li style="z-index:1000;"> <a class="nav-link" href="http://localhost:8080/eudoxus/php/student.php" > <i class="glyphicon glyphicon-education"></i> Φοιτητές</a></li>
                    <li style="z-index:1000;"><a class="nav-link" href="http://localhost:8080/eudoxus/php/publisher.php"  ><i class="glyphicon glyphicon-pencil"></i> Εκδότες</a></li>
                    <li style="z-index:1000;"><a class="nav-link" href="http://localhost:8080/eudoxus/php/secretaries.php" ><i class="glyphicon glyphicon-folder-open"></i> Γραμματείες Τμημάτων</a></li>
                    <li style="z-index:1000;"><a class="nav-link" href="http://localhost:8080/eudoxus/php/diathetes.php" ><i class="glyphicon glyphicon-edit"></i> Διαθέτες δωρεάν ηλεκτρονικών συγγραμμάτων και σημειώσεων</a></li>
                    <li style="z-index:1000;"><a class="nav-link" href="http://localhost:8080/eudoxus/php/libraries.php" ><i class="glyphicon glyphicon-book"></i>Βιβλιοθήκες</a></li>
                    <li style="z-index:1000;"><a class="nav-link" href="http://localhost:8080/eudoxus/php/distribution.php" ><i class="glyphicon glyphicon-duplicate"></i>Σημεία Διανομής</a></li>
                </ul>
            </li>

                <form action="http://localhost:8080/eudoxus/php/search/search.php">
                    <li style="float: right; width: 25%; padding-right: 10px; padding-top: 8px">
                    <input style="float: left; width: 85%;" type="text" name="query" placeholder="Search..">
                        <button style="float: right;position: absolute; padding: 4%" class="btn btn-default" type="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </li>
                </form>
        </ul>
    </nav>
</div>
<script src="JavaScript/jquery-1.10.2.js" type="text/javascript"></script>

<script type="text/javascript">
    $(function() {
        // this will get the full URL at the address bar
        var url = window.location.href;

        // passes on every "a" tag
        $(".clearfix a").each(function() {
            // checks if its the same on the address bar
            if (url == (this.href)) {
                $(this).closest("li").addClass("active");
                //for making parent of submenu active
                $(this).closest("li").parent().parent().addClass("active");
            }
        });
    });
</script>
</body>
</html>