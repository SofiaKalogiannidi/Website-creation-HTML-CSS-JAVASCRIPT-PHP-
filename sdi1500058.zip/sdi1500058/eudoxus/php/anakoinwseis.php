<!DOCTYPE html>
<html lang="en">
<head>

    <link href="http://localhost:8080/eudoxus/css/columns.css" rel="stylesheet" type="text/css">
    <style>

        .boxed {
            border: 3px solid #e15a1f;
            font-family:Arial,Helvetica;
        }

    </style>
</head>
<body>

<?php
include "../php/header.php";
include "../php/menu.php";
?>
<div class="content">




    <div class="panel panel-info" style="width:auto">

        <div class="panel-heading">
            <h2 style="color:#1F77CF;font-family:Arial,Helvetica"> Νέα-Ανακοινώσεις</h2>
        </div>
        <div class="panel-body">

            <div class="clDiv200">09/01/2019 <a href="https://eudoxus.gr/files/Nea_Paratasi_Xeimerinou_2018-19.pdf">Νέα Προθεσμία δηλώσεων συγγραμμάτων </a></div>
        <div class="clDiv200">20/12/2018 <a href="https://eudoxus.gr/files/Paratasi_Xeimerinou_2018-19.pdf"> Προθεσμία δηλώσεων συγγραμμάτων </a></div>
        <div class="clDiv200">1/11/2018 <a href="https://support.mozilla.org/en-US/kb/install-older-version-of-firefox#w_i-still-want-to-downgrade-ae-where-can-i-get-the-previous-version">Πρόβλημα λειτουργίας της εφαρμογής εκδοτών μέσω Mozilla Firefox </a></div>
        <div class="clDiv200">23/10/2018 <a href="https://eudoxus.gr/files/Dianomi_Xeimerinou_2018-19.pdf">Έναρξη Δήλωσης και Διανομής Συγγρμμάτων Χειμερινής Περιόδου </a></div>
        <div class="clDiv200">12/09/2018 <a href="https://eudoxus.gr/files/Dianomi_Xeimerinou_2018-19.pdf">Παράταση Περιόδου καταχώρισης καταλόγων συνολικών  συγγραμμάτων</a></div>


        </div>
    </div>






</div>
</body>

</html>