﻿<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link href="../css/columns.css" rel="stylesheet" type="text/css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel=" stylesheet" type="text/css" href="../css/homepage.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 37%;
  padding-left: 3%;

  column-rule-style: solid;
 
}
.column3 {
	float: left;
  width: 5%;
  padding-left: 2%;
  column-rule-style: solid;
  

}
.column1 {
  float: left;
  width: 15%;
  padding-left: 2%;
  column-rule-style: solid;
  
}
/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
   
}


</style>
</head>
<body>
<div class="content">
<div class="row" style="width:100%">
	<div class="column1">
		<a href="http://localhost:8080/eudoxus/index.php">
			<img src="http://localhost:8080/eudoxus/images/logo.png" style="width:100%" >
		</a>
	</div>
	<div class="column">
		<img src="http://localhost:8080/eudoxus/images/sloganSmall.png"  style="width:100%">
	</div>
	<div class="column">
		<img src="http://localhost:8080/eudoxus/images/topBannerSmall.png" style="width:100%">
	</div>
    <?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
        if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true):
    ?>
        <div class="column3">
            <form action="http://localhost:8080/eudoxus/php/logout.php">
            <button data-placement="bottom"
                    type="submit" class="btn btn-primary btn-md">Αποσύνδεση</button>
            </form>
        </div>
    <?php else:?>
	<div class="column3">
		<button data-placement="bottom"
		type="button" class="btn btn-primary btn-md" 
		data-toggle="popover" title="<h2>Είσοδος</h2>
        <p>Παρακαλώ εισάγετε τα στοιχεία σας για σύνδεση.</p>" data-html="true"
		data-content='<?php include $_SERVER["DOCUMENT_ROOT"]."/eudoxus/php/login.php" ; ?>'>Σύνδεση</button>

		<form action="http://localhost:8080/eudoxus/php/signup.php" >
			<input style="background:#3A78B3;color:white; padding: 10px; border-radius: 5px;" type="submit" value="Εγγραφή" />
		</form>
	</div>
    <?php endif ?>

</div>
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();   
});
</script>
</div>
</body>
</html>