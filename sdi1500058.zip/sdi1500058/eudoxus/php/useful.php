<!DOCTYPE html>
<html lang="en">
<head>

    <link href="http://localhost:8080/eudoxus/css/columns.css" rel="stylesheet" type="text/css">
    <style>

        .boxed {
            border: 3px solid #e15a1f;
            font-family:Arial,Helvetica;
        }
    </style>


</head>
<body>
<?php
include "header.php";
include "../php/menu.php";
?>
<div class="content">




    <div class="panel panel-info" style="width:auto">

        <div class="panel-heading" >
            <h2 style="color:#1F77CF;font-family:Arial,Helvetica"> Χρήσιμα links <i class="glyphicon glyphicon-link"></i></h2>
        </div>
        <div class="panel-body">

            <br><a href="https://repository.kallipos.gr/">Aποθετήριο Κάλλιπος <i class="glyphicon glyphicon-link"></i></a>:Ελληνικά Ακαδημαϊκά Ηλεκτρονικά Συγγράμματα και Βοηθήματα / Κάλλιπος</br>
            <br><a href="http://www.book4book.gr/">Book4Book <i class="glyphicon glyphicon-link"></i></a>:Πλατφόρμα ανταλλαγής σχολικών βιβλίων</br>
            <br><a href="https://eudoxus.gr/EudoxusPlus.html">Εύδοξος+ <i class="glyphicon glyphicon-link"></i></a> :Δράση Ανταλλαγής Συγγραμμάτων</br>
            <br> <a href ="https://twitter.com/eudoxusgr">Εύδοξος στο twitter <i class="glyphicon glyphicon-link"></i></a></br>


        </div>
    </div>


</div>
</body>

</html>