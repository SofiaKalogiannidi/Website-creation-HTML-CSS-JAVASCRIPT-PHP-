<?php
$who = $_GET['who'];

require_once "config.php";

if($who==1){
    $name= $_GET['name'];
    $lastname= $_GET['lastname'];
    $usrnm= $_GET['usrnm'];
    $email= $_GET['email'];
    $psw= $_GET['psw'];
    $am= $_GET['am'];
    $inst= $_GET['inst'];
    $dep= $_GET['dep'];
    $uni= $_GET['uni'];

    $sql="INSERT INTO users (firstname, lastname, email,password,username)
          VALUES ('".$name."', '".$lastname."', '".$email."','".$psw."','".$usrnm."') ";
    $result = mysqli_query($link,$sql);

    $sql="SELECT user_id FROM users ORDER BY user_id DESC LIMIT 1;";
    $result = mysqli_query($link,$sql);
    $id = mysqli_fetch_assoc($result);
    if($inst==1) $inst='ΕΠΙΣΤΗΜΩΝ ΑΓΩΓΗΣ';
    else if($inst==2) $inst='ΕΠΙΣΤΗΜΩΝ ΥΓΕΙΑΣ';
    else if($inst==3) $inst='ΕΠΙΣΤΗΜΗΣ ΦΥΣΙΚΗΣ ΑΓΩΓΗΣ ΚΑΙ ΑΘΛΗΤΙΣΜΟΥ';
    else if($inst==4) $inst='ΘΕΟΛΟΓΙΚΗ';
    else if($inst==5) $inst='ΘΕΤΙΚΩΝ ΕΠΙΣΤΗΜΩΝ';
    else if($inst==6) $inst='ΝΟΜΙΚΗ';
    else if($inst==7) $inst='ΟΙΚΟΝΟΜΙΚΩΝ ΚΑΙ ΠΟΛΙΤΙΚΩΝ ΕΠΙΣΤΗΜΩΝ';
    else $inst='ΦΙΛΟΣΟΦΙΚΗ';

    if($uni==1) $uni='Ανωτάτη Σχολή Καλών Τεχνών';
    else if($uni==2) $uni='Αριστοτέλειο Πανεπιστήμιο Θεσσαλονίκης';
    else if($uni==3) $uni='Γεωπονικό Πανεπιστήμιο Αθηνών';
    else if($uni==4) $uni='Εθνικό και Καποδιστριακό Πανεπιστήμιο Αθηνών';
    else if($uni==5) $uni='Εθνικό Μετσόβιο Πoλυτεχνείο';
    else if($uni==6) $uni='Οικονομικό Πανεπιστήμιο Αθηνών';
    else if($uni==7) $uni='Πανεπιστήμιο Κρήτης';
    else $uni='Πανεπιστήμιο Πειραιά';

    $sql="INSERT INTO students (user_id,am,institution,universtity,department_id)
          VALUES ('".$id['user_id']."','".$am."','".$inst."','".$uni."','".$dep."') ";
    $result = mysqli_query($link,$sql);
    //prepei na kanei logi in twra!

    session_start();

    // Store data in session variables
    $_SESSION["loggedin"] = true;
    $_SESSION["id"] = $id['user_id'];
    $_SESSION["username"] = $usrnm;

    // Redirect user to welcome page
    header("location: student/welcome.php");

}
else{
    $check=$_GET['check'];
    if ($_GET['check'] == 'value1') $check=1;
    else $check=0;
    $email= $_GET['email'];
    $usrnm= $_GET['usrnm'];
    $epsw= $_GET['epsw'];
    $epsw2= $_GET['epsw2'];
    echo $epsw," ",$epsw2;
    $afm= $_GET['afm'];
    $ph1= $_GET['phone1'];
    $ph2= $_GET['phone2'];
    $fax= $_GET['fax'];
    $add= $_GET['adress'];
    $tk= $_GET['tk'];
    $town= $_GET['town'];
    $coun= $_GET['country'];
    $inst=$_GET['doi'];
    if($inst==1) $inst='Δ.Ο.Υ. ΑΓΙΑΣ ΠΑΡΑΣΚΕΥΗΣ';
    else if($inst==2) $inst='Δ.Ο.Υ. ΑΘΗΝΩΝ Α';
    else if($inst==3) $inst='Δ.Ο.Υ. ΑΘΗΝΩΝ Α';
    else if($inst==4) $inst='Δ.Ο.Υ. ΑΘΗΝΩΝ Α';
    else if($inst==5) $inst='Δ.Ο.Υ. ΠΑΛΛΗΝΗΣ';
    if($check==1){  //sutoekdotis
        $name=$_GET['name'];
        $lastname2=$_GET['lastname'];
        $sql="INSERT INTO users (firstname, lastname, email,password,username)
          VALUES ('".$name."', '".$lastname2."', '".$email."','".$epsw."','".$usrnm."') ";
        $result = mysqli_query($link,$sql);

        $sql="SELECT user_id FROM users ORDER BY user_id DESC LIMIT 1;";
        $result = mysqli_query($link,$sql);
        $id = mysqli_fetch_assoc($result);
        $id=$id['user_id'];

        $name=$name. " ";
        $name=$name. $lastname2;
        $sql="INSERT INTO publisher (name,email,AFM,DOI,phone,mob_phone,fax,address,postal_code,country,town,user_id)
          VALUES ('".$name."', '".$email."','".$afm."','".$inst."','".$ph1."','".$ph2."','".$fax."','".$add."','".$tk."','".$coun."','".$town."','".$id."') ";
        $result = mysqli_query($link,$sql);

    }
    else{ //ekdotikos oikos
        $name=$_GET['name'];
        $name2= $_GET['name2'];
        $name3= $_GET['name3'];
        $email2= $_GET['email2'];
        $phone3= $_GET['phone3'];

        $sql="INSERT INTO users (firstname, lastname, email,password,username)
          VALUES ('".$name2."', '".$name3."', '".$email2."','".$psw."','".$usrnm."') ";
        $result = mysqli_query($link,$sql);

        $sql="SELECT user_id FROM users ORDER BY user_id DESC LIMIT 1;";
        $result = mysqli_query($link,$sql);
        $id = mysqli_fetch_assoc($result);
        $id=$id['user_id'];

        $name=$name. " ";
        $name=$name. $lastname;
        $sql="INSERT INTO publisher (name,email,AFM,DOI,phone,mob_phone,fax,address,postal_code,country,town,user_id,phone_user)
          VALUES ('".$name."', '".$email."','".$afm."','".$inst."','".$ph1."','".$ph2."','".$fax."','".$add."','".$tk."','".$coun."','".$town."','".$id."','".$phone3."') ";
        $result = mysqli_query($link,$sql);

        session_start();

        // Store data in session variables
        $_SESSION["loggedin"] = true;
        $_SESSION["id"] = $id;
        $_SESSION["username"] = $usrnm;

        // Redirect user to welcome page
        header("location: http://localhost:8080/eudoxus/php/publisher/pub_welcome.php");

    }
}
?>