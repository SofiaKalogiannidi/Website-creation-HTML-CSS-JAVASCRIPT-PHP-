<?php

include "../config.php";

/* Get username */
$uname = $_POST['uname'];

/* Query */
$query = "select count(*) as cntUser from users where username='".$uname."'";

$result = mysqli_query($link,$query);

$row = mysqli_fetch_array($result);

$count = $row['cntUser'];

echo $count;