<!DOCTYPE html>
<html lang="en">
<head>
    <title>Eudoxus</title>
    <meta charset="utf-8">
    <link href="http://localhost:8080/eudoxus/css/menu.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <script src="http://osvaldas.info/examples/main.js"></script>

    <script src="http://osvaldas.info/examples/drop-down-navigation-touch-friendly-and-responsive/doubletaptogo.js"></script>

    <script>
        $( function()
        {
            $( '#nav li:has(ul)' ).doubleTapToGo();
        });
    </script>
    <style>
        #nav > ul > li {
            width: auto;
            height: 100%;
            float: left;
            padding: 0.4%;
        }
        html {
            font-size: 30%;
            -webkit-text-size-adjust: 100%;
            -moz-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
            -o-text-size-adjust: 100%;
            text-size-adjust: 100%;
        }
    </style>
</head>
<body >

<div class="content">
    <nav id="nav" role="navigation"> <a href="#nav" title="Show navigation">Show navigation</a> <a href="#" title="Hide navigation">Hide navigation</a>
        <ul class="clearfix">
            <li><a href="http://localhost:8080/eudoxus/php/publisher/pub_welcome.php">Εκδότης</a></li>
            <li><a href="#">Αναφορές</a></li>
            <li><a href="http://localhost:8080/eudoxus/php/publisher/books.php">Βιβλία</a></li>
            <li><a href="#">Σημεία Διανομής</a></li>
            <li><a href="#">Επιλεγμένα Βιβλία</a></li>
            <li><a href="#">Διανομή με Courier</a></li>
            <li><a href="#">Σύστημα Πληρωμών</a></li>
            <li><a href="#">Παραγγελίες Βιβλιοθηκων</a></li>
        </ul>
    </nav>
</div>
<script src="JavaScript/jquery-1.10.2.js" type="text/javascript"></script>

<script type="text/javascript">
    $(function() {
        // this will get the full URL at the address bar
        var url = window.location.href;

        // passes on every "a" tag
        $(".clearfix a").each(function() {
            // checks if its the same on the address bar
            if (url == (this.href)) {
                $(this).closest("li").addClass("active");
                //for making parent of submenu active
                $(this).closest("li").parent().parent().addClass("active");
            }
        });
    });
</script>
</body>
</html>