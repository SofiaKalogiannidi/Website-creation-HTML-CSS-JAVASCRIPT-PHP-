<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// Store data in session variables
$id=$_SESSION["id"];

// Include config file
require_once "../config.php";

// mysql select query
$query = "SELECT b.* FROM books b,publisher p where b.publisher_id=p.id and p.user_id='".$id."'";
$result1 = mysqli_query($link, $query);

?>
<!DOCTYPE html>
<head>
    <title>Δήλωση Συγγραμάτων</title>
    <link href="http://localhost:8080/eudoxus/css/columns.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/homepage.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/accordion.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <meta charset="utf-8">
    <style>
        body {
            background-image:url("http://localhost:8080/eudoxus/images/books.jpg");
        }
        .column {
            float: left;
            width: 10%;
            padding: 5px;
        }
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
        .tabcontent:after {
            content: "";
            display: table;
            clear: both;
        }
        #customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td, #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:hover {background-color: #ddd;}
        #customers tr.alt:hover {background-color: #ddd;}

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #b3d7ff;
        }
        .selected {
            background-color: #b3d7ff;
        }
    </style>
</head>
<?php
include "./../../php/header.php";
include ("menu.php");
?>
<body>
<div class="content">
    <div class="panel panel-info">
        <div class="panel-heading">
            Καταχωριμένα Βιβλία Εκδότη(Εμφανίζονται εγγραφές)
        </div>
        <div class="panel-body">
            <table id="customers">
                <tr>
                    <th style="font-weight: bold;">Ολοκληρωμένη Εγγραφή</th>
                    <th style="font-weight: bold;">Κωδικός</th>
                    <th style="font-weight: bold;">Ενεργό</th>
                    <th style="font-weight: bold;">Τύπος</th>
                    <th style="font-weight: bold;">Τίτλος</th>
                    <th style="font-weight: bold;">Συγγραφείς</th>
                </tr>
                <?php while($row = mysqli_fetch_array($result1)):;?>
                    <tr>
                        <?php
                        $sql="SELECT s.* FROM writters s,written w WHERE w.writter_id = s.writter_id and w.book_id = '".$row['id']."'";
                        $writer= mysqli_query($link,$sql);
                        ?>
                        <td></td>
                        <td><?php echo $row['id'];?></td>
                        <td><input type="checkbox" checked></td>
                        <td><?php echo $row['book_type'];?></td>
                        <td><?php echo $row['title'];?></td>
                        <td><?php $w = mysqli_fetch_array($writer);
                            while(1) {
                                echo $w['firstname'];
                                echo " ";
                                echo $w['lastname'];
                                if(!$w = mysqli_fetch_array($writer)){
                                    break;
                                }
                                echo ", ";
                            }
                            ?></td>
                    </tr>
                <?php endwhile;?>
            </table>
            <div class="row">
                <label style=" padding-left: 1%; padding-right:0.5%;padding-top: 1%">
                    <button class="btn btn-default" type="submit" id="a" style="display:inline; float:left;">Προσθήκη Συγγράματος</button>
                </label>
                <label style=" padding-right: 0.5%; padding-top: 1%">
                    <button class="btn btn-default" type="submit" id="a" style="display:inline; float:left;">Φίλτρα Αναζήτησης</button>
                </label>
                <label style=" padding-right: 0.5%; padding-top: 1%">
                    <button class="btn btn-default" type="submit" id="a" style="display:inline; float:left;">Πλήρης Λίστα Βιβλίων</button>
                </label>
                <label style=" padding-right: 0.5%; padding-top: 1%">
                    <button class="btn btn-default" type="submit" id="a" style="display:inline; float:left;">Εκρεμέίς Εγγραφές</button>
                </label>
                <label style=" padding-right: 0.5%; padding-top: 1%">
                    <button class="btn btn-default" type="submit" id="a" style="display:inline; float:left;">Νέες Εγγραφές</button>
                </label>
                <label style=" padding-right: 1%; padding-top: 1%">
                    <button class="btn btn-default" type="submit" id="a" style="display:inline; float:left;">Αίτηση Κοστολόγησης</button>
                </label>
            </div>
        </div>
    </div>
    <script>
        $("#customers tr").click(function(){
            $(this).addClass('selected').siblings().removeClass('selected');
        });
    </script>
</div>
</body>