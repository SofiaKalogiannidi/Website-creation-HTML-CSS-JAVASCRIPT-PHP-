<?php
$q = $_GET['query'];

require_once "../config.php";

$sql="SELECT b.*,p.name FROM books b,publisher p where((b.title='".$q."')or(b.ISBN='".$q."')or(b.version='".$q."')) and (b.book_type='book') and (b.publisher_id=p.id)";
$result = mysqli_query($link,$sql);

$sql2="select count(*) from (SELECT * FROM books where((title='".$q."')or(ISBN='".$q."')or(version='".$q."'))and (book_type='book')) as x;";
$result2 = mysqli_query($link,$sql2);

$sql3="SELECT b.*,p.name FROM books b,publisher p where((b.title='".$q."')or(b.ISBN='".$q."')or(b.version='".$q."')) and (b.book_type='e-book') and (b.publisher_id=p.id)";
$result3 = mysqli_query($link,$sql3);

$sql4="select count(*) from (SELECT * FROM books where((title='".$q."')or(ISBN='".$q."')or(version='".$q."'))and (book_type='e-book')) as x;";
$result4 = mysqli_query($link,$sql4);

$sql5="SELECT b.*,p.name FROM books b,publisher p where((b.title='".$q."')or(b.ISBN='".$q."')or(b.version='".$q."')) and (b.book_type='free') and (b.publisher_id=p.id)";
$result5 = mysqli_query($link,$sql5);

$sql6="select count(*) from (SELECT * FROM books where((title='".$q."')or(ISBN='".$q."')or(version='".$q."'))and (book_type='free')) as x;";
$result6 = mysqli_query($link,$sql6);

$sql7="SELECT b.*,p.name FROM books b,publisher p,distribution d,distribution_point dp where (dp.name='".$q."' or dp.address='".$q."' or dp.phone_number='".$q."')and (dp.id=d.point_id)and (d.book_id=b.id) and (b.publisher_id=p.id)";
$result7 = mysqli_query($link,$sql7);

$sql8="select count(*) from (SELECT b.*,p.name FROM books b,publisher p,distribution d,distribution_point dp where (dp.name='".$q."' or dp.address='".$q."' or dp.phone_number='".$q."')and (dp.id=d.point_id)and (d.book_id=b.id) and (b.publisher_id=p.id)) as x;";
$result8 = mysqli_query($link,$sql8);

$sql9="SELECT b.*,p.name FROM books b,publisher p,written wtn,writters w where (w.firstname='".$q."' or w.lastname='".$q."' )and (w.writter_id=wtn.writter_id) and (wtn.book_id=b.id) and (b.publisher_id=p.id)";
$result9 = mysqli_query($link,$sql9);

$sql10="select count(*) from (SELECT b.*,p.name FROM books b,publisher p,written wtn,writters w where (w.firstname='".$q."' or w.lastname='".$q."' )and (w.writter_id=wtn.writter_id) and (wtn.book_id=b.id) and (b.publisher_id=p.id)) as x;";
$result10 = mysqli_query($link,$sql10);

$sql11="SELECT b.*,p.name FROM books b,publisher p where (p.name='".$q."')and (p.id=b.publisher_id)";
$result11 = mysqli_query($link,$sql11);

$sql12="select count(*) from (SELECT b.*,p.name FROM books b,publisher p where (p.name='".$q."')and (p.id=b.publisher_id)) as x;";
$result12 = mysqli_query($link,$sql12);


$sql13="SELECT dp.* FROM distribution_point dp where (dp.name='".$q."' or dp.phone_number='".$q."' or dp.address='".$q."')";
$result13 = mysqli_query($link,$sql13);

$sql14="select count(*) from (SELECT dp.* FROM distribution_point dp where (dp.name='".$q."' or dp.phone_number='".$q."' or dp.address='".$q."')) as x;";
$result14 = mysqli_query($link,$sql14);

$sql15="SELECT b.*,p.name 
        FROM department u,university_subject us,subject_books sb,books b,publisher p
        where (u.name='".$q."') and u.id=us.uni_id and us.sub_id=sb.id and sb.book_id=b.id and b.publisher_id=p.id ";
$result15 = mysqli_query($link,$sql15);

$sql16="select count(*) from (SELECT b.*,p.name 
        FROM department u,university_subject us,subject_books sb,books b,publisher p
        where (u.name='".$q."') and u.id=us.uni_id and us.sub_id=sb.id and sb.book_id=b.id and b.publisher_id=p.id) as x;";
$result16 = mysqli_query($link,$sql16);

$sql17="SELECT b.*,p.name 
        FROM subject s,subject_books sb,books b,publisher p
        where (s.name='".$q."' or s.proffesor='".$q."' or s.semester='".$q."') and s.id=sb.subject_id and sb.book_id=b.id and b.publisher_id=p.id ";
$result17 = mysqli_query($link,$sql17);

$sql18="select count(*) from (SELECT b.*,p.name 
        FROM subject s,subject_books sb,books b,publisher p
        where (s.name='".$q."' or s.proffesor='".$q."' or s.semester='".$q."') and s.id=sb.subject_id and sb.book_id=b.id and b.publisher_id=p.id ) as x;";
$result18 = mysqli_query($link,$sql18);
////////////////////////

?>


</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <link href="http://localhost:8080/eudoxus/css/columns.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/homepage.css" rel="stylesheet" type="text/css">  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
            background-image:url("http://localhost:8080/eudoxus/images/large.jpg");
        }

        .row:after {
            display: table;
            clear: both;
        }

        .card {
            float: left;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            max-width: 20%;
            padding: 10px;
            margin-right: 10px;
            margin-left: 10px;
            text-align: center;
            font-family: arial;
            background: white;
        }

        .price {
            color: grey;
            font-size: 15px;
        }

        .card button {
            border: none;
            outline: 0;
            padding: 3px;
            color: white;
            background-color: deepskyblue;
            text-align: center;
            cursor: pointer;
            width: 100%;
            font-size: 18px;
        }

        .card button:hover {
            opacity: 0.7;
        }

    </style>
</head>
<body >
<?php
include "../header.php";
include "./../menu.php";
?>
<div class="content">
    <div class="panel panel-info">
        <div class="panel-heading">
            <?php $row2 = mysqli_fetch_array($result2);
                  $row4 = mysqli_fetch_array($result4);
                  $row6 = mysqli_fetch_array($result6);
                  $row8 = mysqli_fetch_array($result8);
                  $row10 = mysqli_fetch_array($result10);
                  $row12 = mysqli_fetch_array($result12);
                  $row14 = mysqli_fetch_array($result14);
                  $row16 = mysqli_fetch_array($result16);
                  $row18 = mysqli_fetch_array($result18);?>
            Αποτελέσματα : <?php echo $row2[0]+$row4[0]+$row6[0]+$row8[0]+$row10[0]+$row12[0]+$row14[0]+$row16[0]+$row18[0]?>
            <?php include "./../../html/search.html"; ?>
        </div>
        <div class="panel-body">
            <div style="width:50%;margin-left:40%" class="container">
                <ul class="pagination">
                    <li><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                </ul>
            </div>
            <div class="row">
                <?php while($row1 = mysqli_fetch_array($result)):;?>
                    <div class="card">
                        <a href="http://localhost:8080/eudoxus/php/search/showBookData.php?var=<?php echo $row1[0];?>"><?php echo $row1[1]?></a>
                        <img src="<?php echo $row1[5]?>" alt="Denim Jeans" style="width:100%; margin-top:10px;">
                        <div style="margin-top: 10px">Έκδοση: <?php echo $row1[2]?></div>
                        <p class="price">ISBN:<?php echo $row1[3]?></p>
                        Εκδοτικός Οίκος: <?php echo $row1[7]?>
                        <p><button><span class="glyphicon glyphicon-new-window"></span> Ιστοσελίδα</button></p>
                    </div>
                <?php endwhile;?>
                <?php while($row3 = mysqli_fetch_array($result3)):;?>
                    <div class="card">
                        <a href="http://localhost:8080/eudoxus/php/search/showBookData.php?var=<?php echo $row3[0];?>"><?php echo $row3[1]?></a>
                        <img src="<?php echo $row3[5]?>" alt="Denim Jeans" style="width:100%; margin-top:10px;">
                        <div style="margin-top: 10px">Έκδοση: <?php echo $row3[2]?></div>
                        <p class="price">ISBN:<?php echo $row3[3]?></p>
                        Εκδοτικός Οίκος: <?php echo $row3[7]?>
                        <p><button><span class="glyphicon glyphicon-new-window"></span> Ιστοσελίδα</button></p>
                    </div>
                <?php endwhile;?>
                <?php while($row5 = mysqli_fetch_array($result5)):;?>
                    <div class="card">
                        <a href="http://localhost:8080/eudoxus/php/search/showBookData.php?var=<?php echo $row5[0];?>"><?php echo $row5[1]?></a>
                        <img src="<?php echo $row5[5]?>" alt="Denim Jeans" style="width:100%; margin-top:10px;">
                        <div style="margin-top: 10px">Έκδοση: <?php echo $row5[2]?></div>
                        <p class="price">ISBN:<?php echo $row5[3]?></p>
                        Εκδοτικός Οίκος: <?php echo $row5[7]?>
                        <p><button><span class="glyphicon glyphicon-new-window"></span> Ιστοσελίδα</button></p>
                    </div>
                <?php endwhile;?>
                <?php while($row7 = mysqli_fetch_array($result7)):;?>
                    <div class="card">
                        <a href="http://localhost:8080/eudoxus/php/search/showBookData.php?var=<?php echo $row7[0];?>"><?php echo $row7[1]?></a>
                        <img src="<?php echo $row7[5]?>" alt="Denim Jeans" style="width:100%; margin-top:10px;">
                        <div style="margin-top: 10px">Έκδοση: <?php echo $row7[2]?></div>
                        <p class="price">ISBN:<?php echo $row7[3]?></p>
                        Εκδοτικός Οίκος: <?php echo $row7[7]?>
                        <p><button><span class="glyphicon glyphicon-new-window"></span> Ιστοσελίδα</button></p>
                    </div>
                <?php endwhile;?>
                <?php while($row9 = mysqli_fetch_array($result9)):;?>
                    <div class="card">
                        <a href="http://localhost:8080/eudoxus/php/search/showBookData.php?var=<?php echo $row9[0];?>"><?php echo $row9[1]?></a>
                        <img src="<?php echo $row9[5]?>" alt="Denim Jeans" style="width:100%; margin-top:10px;">
                        <div style="margin-top: 10px">Έκδοση: <?php echo $row9[2]?></div>
                        <p class="price">ISBN:<?php echo $row9[3]?></p>
                        Εκδοτικός Οίκος: <?php echo $row9[7]?>
                        <p><button><span class="glyphicon glyphicon-new-window"></span> Ιστοσελίδα</button></p>
                    </div>
                <?php endwhile;?>
                <?php while($row11 = mysqli_fetch_array($result11)):;?>
                    <div class="card">
                        <a href="http://localhost:8080/eudoxus/php/search/showBookData.php?var=<?php echo $row11[0];?>"><?php echo $row11[1]?></a>
                        <img src="<?php echo $row11[5]?>" alt="Denim Jeans" style="width:100%; margin-top:10px;">
                        <div style="margin-top: 10px">Έκδοση: <?php echo $row11[2]?></div>
                        <p class="price">ISBN:<?php echo $row11[3]?></p>
                        Εκδοτικός Οίκος: <?php echo $row11[7]?>
                        <p><button><span class="glyphicon glyphicon-new-window"></span> Ιστοσελίδα</button></p>
                    </div>
                <?php endwhile;?>
                <?php while($row15 = mysqli_fetch_array($result15)):;?>
                    <div class="card">
                        <a href="http://localhost:8080/eudoxus/php/search/showBookData.php?var=<?php echo $row15[0];?>"><?php echo $row15[1]?></a>
                        <img src="<?php echo $row15[5]?>" alt="Denim Jeans" style="width:100%; margin-top:10px;">
                        <div style="margin-top: 10px">Έκδοση: <?php echo $row15[2]?></div>
                        <p class="price">ISBN:<?php echo $row15[3]?></p>
                        Εκδοτικός Οίκος: <?php echo $row15[7]?>
                        <p><button><span class="glyphicon glyphicon-new-window"></span> Ιστοσελίδα</button></p>
                    </div>
                <?php endwhile;?>
                <?php while($row17 = mysqli_fetch_array($result17)):;?>
                    <div class="card">
                        <a href="http://localhost:8080/eudoxus/php/search/showBookData.php?var=<?php echo $row17[0];?>"><?php echo $row17[1]?></a>
                        <img src="<?php echo $row17[5]?>" alt="Denim Jeans" style="width:100%; margin-top:10px;">
                        <div style="margin-top: 10px">Έκδοση: <?php echo $row17[2]?></div>
                        <p class="price">ISBN:<?php echo $row17[3]?></p>
                        Εκδοτικός Οίκος: <?php echo $row17[7]?>
                        <p><button><span class="glyphicon glyphicon-new-window"></span> Ιστοσελίδα</button></p>
                    </div>
                <?php endwhile;?>
                <?php while($row13 = mysqli_fetch_array($result13)):;?>
                    <div class="card">
                        ΣΗΜΕΙΟ ΔΙΑΝΟΜΗΣ:
                        <?php echo $row13[1]?>
                        <img src="http://localhost:8080/eudoxus/images/map.jpg" alt="Denim Jeans" style="width:100%; margin-top:10px;">
                        <div style="margin-top: 10px"><span class="glyphicon glyphicon-map-marker"></span><?php echo $row13[2]?></div>
                        <p class="price"> <span class="glyphicon glyphicon-earphone"></span> <?php echo $row13[3]?></p>
                        <p><button><span class="glyphicon glyphicon-globe"></span> Χάρτης</button></p>
                    </div>
                <?php endwhile;?>
            </div>
            <div style="width:50%;margin-left:40%" class="container">
                <ul class="pagination">
                    <li><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
</body>