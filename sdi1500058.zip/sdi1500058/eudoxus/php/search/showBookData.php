<?php
$q = $_GET['var'];
require_once "../config.php";

$sql="SELECT DISTINCT b.*,p.name
      FROM books b,distribution_point dp,distribution d,publisher p,writters w, written wtn
      where b.id='".$q."' and b.publisher_id=p.id and b.id=d.book_id and b.id=wtn.book_id and d.point_id=dp.id and w.writter_id=wtn.writter_id";
$result = mysqli_query($link,$sql);

$sql2="SELECT DISTINCT dp.*
      FROM books b,distribution_point dp,distribution d,publisher p,writters w, written wtn
      where b.id='".$q."' and b.publisher_id=p.id and b.id=d.book_id and b.id=wtn.book_id and d.point_id=dp.id and w.writter_id=wtn.writter_id";
$result2 = mysqli_query($link,$sql2);

$sql3="SELECT DISTINCT w.*
      FROM books b,distribution_point dp,distribution d,publisher p,writters w, written wtn
      where b.id='".$q."' and b.publisher_id=p.id and b.id=d.book_id and b.id=wtn.book_id and d.point_id=dp.id and w.writter_id=wtn.writter_id";
$result3 = mysqli_query($link,$sql3);

////////////////////////

?>


</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <link href="http://localhost:8080/eudoxus/css/columns.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/homepage.css" rel="stylesheet" type="text/css">  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
            background-image:url("http://localhost:8080/eudoxus/images/large.jpg");
        }

        .row:after {
            display: table;
            clear: both;
        }

        .card {
            margin-left: 20%;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            max-width: 60%;
            padding: 10px;
            margin-right: 10px;;
            text-align: center;
            font-family: arial;
            background: white;
        }

        .card button {
            width:50%;
            margin-left:25%
            border: none;
            outline: 0;
            padding: 3px;
            color: white;
            background-color: deepskyblue;
            text-align: center;
            cursor: pointer;
            font-size: 18px;
        }

        .card button:hover {
            opacity: 0.7;
        }

    </style>
</head>
<body >
<?php
include "./../../html/header.php";
include "./../menu.php";
?>
<div class="content">
    <div class="panel panel-info">
        <div class="panel-heading">
            <h4 style="text-align: center">Γενικές πληροφορίες βιβλίου</h4>
        </div>
    </div>
    <div class="panel-body">
            <div class="card">
                <?php while($row1 = mysqli_fetch_array($result)):;?>
                    <a href="http://localhost:8080/eudoxus/php/search/showBookData.php?var=<?php echo $row1[0];?>"><?php echo $row1[1]?></a>
                    <img src="<?php echo $row1[5]?>" alt="Denim Jeans" style="width:50%;margin-left:25%; margin-top:10px;">
                    <p style="margin-top: 10px">ISBN:<?php echo $row1[3];echo '&nbsp';?> Έκδοση: <?php echo $row1[2]?></p>
                    <p>Εκδοτικός Οίκος: <?php echo $row1[7]?></p>
                    <p>Συγγραφείς:
                        <?php while($row3 = mysqli_fetch_array($result3)):;?>
                            <?php echo $row3[1];echo '&nbsp';echo $row3[2];?>
                        <?php endwhile;?>
                    </p>
                    <?php while($row2 = mysqli_fetch_array($result2)):;?>
                    <p>Σημείο Παραλαβής:<?php echo $row2[1];?> </p>
                    <p><span class="glyphicon glyphicon-map-marker"><?php echo $row2[2];echo '&nbsp';?><span class="glyphicon glyphicon-earphone"></span> <?php echo $row2[3];?> </p>
                    <?php endwhile;?>
                    <p><button><span class="glyphicon glyphicon-new-window"></span> Ιστοσελίδα</button></p>
                <?php endwhile;?>
            </div>
    </div>
</div>
</body>