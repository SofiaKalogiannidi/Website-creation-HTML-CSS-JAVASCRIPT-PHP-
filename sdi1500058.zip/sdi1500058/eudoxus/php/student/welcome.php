
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="../../css/columns.css" rel="stylesheet" type="text/css">
    <link href="../../css/homepage.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>Eudoxus</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta charset="utf-8">
    <style>
        .input-containerf {
            display: -ms-flexbox; /* IE10 */
            display: flex;
            width: 50%;
        }

        .iconf {
            padding: 4px;
            background: #b3d7ff;
            color: white;
            min-width: 25px;
            text-align: center;
        }

        .input-fieldf {
            width: 100%;
            padding: 4px;
            outline: none;
        }

        .input-fieldf:focus {
            border: 2px solid #b3d7ff;
        }

        /* Set a style for the submit button */
        .btnf {
            background-color: #b3d7ff;
            color: white;
            border: none;
            cursor: pointer;
            width: 10%;
            opacity: 0.9;
        }

        .btnfsub {
            background-color: #b3d7ff;
            color: white;
            border: none;
            cursor: pointer;
            width: 40%;
            opacity: 0.9;
        }

        .btnf:hover {
            opacity: 1;
        }
        body {
            background-color:lightsalmon;
        }
        .column {
            float: left;
            width: 50%;
            padding: 10px;
        }
        .row:after {
            display: table;
            clear: both;
        }
    </style>

</head>
<body >
<?php
include "./../../php/header.php";
include "./menu.php";
?>

<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$id=$_SESSION["id"];

require_once "../config.php";

$sql="SELECT u.*,s.*,d.name
      FROM users u,students s,department d 
      WHERE u.user_id='".$id."' and u.user_id=s.user_id and s.department_id=d.id ";
$result = mysqli_query($link,$sql);

////////////////////////
?>
<div class="content">
    <div class="panel panel-info">
        <div class="panel-heading">Στοιχεία Φοιτητή</div>
        <?php $row = mysqli_fetch_array($result); ?>
        <div class="panel-body">
            <div class="row">
                <div class="column">
                    Ίδρυμα
                </div>
                <div class="column">
                    <div class="row">
                        <?php echo $row[9]?>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="column">
                    Σχολή
                </div>
                <div class="column">
                    <div class="row">
                        <?php echo $row[8]?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="column">
                    Τμήμα
                </div>
                <div class="column">
                    <div class="row">
                        <?php echo $row[12]?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="column">
                    Αριθμός Μητρώου
                </div>
                <div class="column">
                    <div class="row">
                        <?php echo $row[7]?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="column">
                    Όνομα
                </div>
                <div class="column">
                    <div class="row">
                        <?php echo $row[1]?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="column">
                    Επώνυμο
                </div>
                <div class="column">
                    <div class="row">
                        <?php echo $row[2]?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="column">
                    Προσωπικό E-mail Επικοινωνίας
                </div>
                <div class="column">
                    <div class="row">
                        <?php echo $row[3]?>
                        <button id="7" class="btnf"><i class="fa fa-pencil"></i></button>
                    </div>
                    <form id="form7" action="saveStudentchange.php" style="max-width:500px;margin:auto;display:none;" method="get">
                        <input type="hidden" id="what" name="what" value="7">
                        <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">
                        <div class="input-containerf">
                            <i class="fa fa-user iconf"></i>
                            <input class="input-fieldf" type="email" placeholder="Νέo E-mail" name="email">
                            <button type="submit" class="btnfsub">Αλλαγή</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="column">
                    Αριθμός Μαθημάτων για τα οποία έχετε ήδη παραλάβει συγγράμματα πριν το σύστημα Εύδοξος
                </div>
                <div class="column">
                    0
                </div>
            </div>
            <div class="row">
                <button style="margin-left:200px;" id="8" class="btnf"><i class="fa fa-pencil">Κωδικός Πρόσβασης</i></button>
                <form id="form8" action="saveStudentchange.php" style="max-width:500px;margin:auto;display:none;" method="get">
                    <input type="hidden" id="what" name="what" value="8">
                    <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">
                    <div class="input-containerf">
                        <i class="fa fa-key iconf"></i>
                        <input class="input-fieldf" type="password" placeholder="Νέoς Κωδικός" name="pass">
                        <button type="submit" class="btnfsub">Αλλαγή</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

</div>
</body>

<script>
    $(document).ready(function(){
        $("#7").click(function(){
            $("#form7").toggle();
        });
    });

    $(document).ready(function(){
        $("#8").click(function(){
            $("#form8").toggle();
        });
    });
</script>