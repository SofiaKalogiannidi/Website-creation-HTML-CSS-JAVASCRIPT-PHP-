<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$id=$_SESSION["id"];
require_once "../config.php";

$query = "Delete  FROM selected_books where student_id='".$id."'";
if(!isset($_POST["book"])){
    header("location: recieving_points.php");
}
mysqli_query($link, $query);
$books=$_POST["book"];
$subjects=$_POST["subject"];
for ($i = 0; $i <count($books); $i++){
    $query = "insert into selected_books(student_id, book_id, subject_id) values('".$id."','".$books[$i]."','".$subjects[$i]."')";
    $query =  mysqli_query($link, $query);
}
header("location: recieving_points.php");
?>