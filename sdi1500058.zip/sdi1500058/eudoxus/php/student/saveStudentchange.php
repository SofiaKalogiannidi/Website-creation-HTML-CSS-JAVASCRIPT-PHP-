<?php
$who = $_GET['what'];
$id = $_GET['id'];

require_once "../config.php";

if($who==7){
    $email = $_GET['email'];

    $sql="UPDATE users
          SET email ='".$email."' 
          WHERE user_id= '".$id."';";
    $result = mysqli_query($link,$sql);


}
else {
    $email = $_GET['pass'];

    $sql = "UPDATE users
          SET password ='" . $email . "' 
          WHERE user_id= '" . $id . "';";
    $result = mysqli_query($link, $sql);
}

header("location: http://localhost:8080/eudoxus/php/student/welcome.php");
