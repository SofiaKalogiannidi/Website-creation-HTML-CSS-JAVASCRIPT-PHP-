<?php
session_start();
// Store data in session variables
$id=$_SESSION["id"];

// Include config file
require_once "../config.php";

// mysql select query
$query = "SELECT * FROM department"; //girnao tis plirofories

// for method 1

$result1 = mysqli_query($link, $query); //den eimai kan sigouri giati douleuei??

$query = "SELECT department_id FROM students where students.user_id=?"; //apo edo kai kato einai axrista pros to paeon
if($stmt = mysqli_prepare($link, $query)) {
// Bind variables to the prepared statement as parameters
    mysqli_stmt_bind_param($stmt, "s", $id);
}
// Set parameters
$result2 = mysqli_query($link, $query);
?>
<!DOCTYPE html>
<head>
    <title>Δήλωση Συγγραμάτων</title>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link href="http://localhost:8080/eudoxus/css/checkbox.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/columns.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/homepage.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/sidebar.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/accordion.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <meta charset="utf-8">
    <style>
        body {
            background-image:url("http://localhost:8080/eudoxus/images/books.jpg");
        }
        .column {
            float: left;
            width: 10%;
            padding: 5px;
        }
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
        .tabcontent:after {
            content: "";
            display: table;
            clear: both;
        }
        .btn-default{
            background-color: #e15a1f;
            border: 0.313em solid transparent; /* 5 */
            color=white;

        }
    </style>
</head>
<?php
include "./../../php/header.php";
include ("menu.php");
?>
<body>
    <div class="content">
        <div class="panel panel-info">
            <div class="panel-heading">
                Λίστα Δηλώσεων:
            </div>
            <div class="panel-body">
                <form  action="http://localhost:8080/eudoxus/php/student/save_changes.php" method="post" id="a">
                <div class="row">
                    <label style="padding-top: 1%">
                        <select class="btn btn-default" style="display:inline">
                            <option value="1" selected="selected">Δημιουργία Νέας Δήλωσης</option>
                            <option value="2">Επισκόπιση...</option>
                        </select>
                    </label>
                    <label style="padding-top: 1%">Επιλέξτε Τμήμα:
                        <select class="btn btn-default" style="display:inline">   //s auto to select emfanizonte ta apotelesmata ap ti vasi
                            <?php while($row2 = mysqli_fetch_array($result1)):;?>
                                <option value="<?php echo $row2[0];?>"><?php echo $row2[1];?></option>
                            <?php endwhile;?>
                        </select>
                    </label>
                    <label style="float:right; padding-right: 5%; padding-top: 1%">
                        <button class="btn btn-default" type="submit" id="a" style="display:inline; float:right;">Τελική Υποβολή Δήλωσης</button>
                    </label>
                </div>
                <div style="padding-top: 2%">
                    <div class="tab">
                        <button type="button" class="tablinks" onclick="openCity(event, 'ex1')" id="defaultOpen">1o Εξάμηνο</button>
                        <button type="button" class="tablinks" onclick="openCity(event, 'ex3')">3o Εξάμηνο</button>
                        <button type="button" class="tablinks" onclick="openCity(event, 'ex5')">5o Εξάμηνο</button>
                        <button type="button" class="tablinks" onclick="openCity(event, 'ex5')">7o Εξάμηνο</button>
                    </div>

                    <?php for ($i = 1; $i <= 7; $i+=2):;?>
                        <div id="<?php echo "ex",$i?>" class="tabcontent">
                            <?php
                            $sql="SELECT * FROM subject WHERE semester = '".$i."'";
                            $result = mysqli_query($link,$sql);
                            ?>
                            <?php while($row1 = mysqli_fetch_array($result)):;?>
                                <button  type="button" onclick="myFunction('<?php echo $row1[1];?>')" class="w3-btn w3-block w3-black w3-left-align">
                                    <?php
                                        $sql="SELECT * FROM selected_books WHERE student_id = '".$id."' and subject_id = '".$row1['id']."'";
                                        $checked= mysqli_query($link,$sql);
                                    ?>
                                    <?php if(mysqli_fetch_array($checked) !== null):?>
                                        <input class="form-check-input" style="float:right" type="checkbox"  id="<?php echo $row1['id'];?>" name="subject[]" value="<?php echo $row1['id'];?>" checked>
                                    <?php else:?>
                                        <input class="form-check-input" style="float:right" type="checkbox"  id="<?php echo $row1['id'];?>" name="subject[]" value="<?php echo $row1['id'];?>">
                                    <?php endif ?>
                                    <p style="display:inline; font-weight: bold;"><?php echo $row1['name'];?>, </p>
                                    <p><small><?php echo $row1['proffesor'];?>, Εξάμηνο <?php echo $i;?>ο, Χειμερινό</small></p>
                                </button>
                                <div id="<?php echo $row1[1];?>" class="w3-container w3-hide">
                                    <?php
                                    $sql="SELECT b.* FROM subject_books r,books b WHERE b.active='1' and  r.book_id=b.id and r.subject_id = '".$row1['id']."'" ;
                                    $result1 = mysqli_query($link,$sql);?>
                                    <?php while($row = mysqli_fetch_array($result1)):;?>
                                        <div style="padding-left: 3%; padding-rigt: 3%">
                                        <?php
                                        $sql="SELECT * FROM selected_books WHERE student_id = '".$id."' and book_id = '".$row['id']."'";
                                        $checked= mysqli_query($link,$sql);
                                        $sql="SELECT s.* FROM writters s,written w WHERE w.writter_id = s.writter_id and w.book_id = '".$row['id']."'";
                                        $writer= mysqli_query($link,$sql);
                                        $sql="SELECT p.name FROM books b,publisher p WHERE b.publisher_id = p.id and b.id = '".$row['id']."'";
                                        $publisher= mysqli_query($link,$sql);
                                        ?>
                                        <?php if(mysqli_fetch_array($checked) !== null):?>
                                            <input type="checkbox" data-group="<?php echo $row1['id'];?>" name="book[]" value="<?php echo $row['id'];?>" checked>
                                        <?php else:?>
                                            <input type="checkbox" data-group="<?php echo $row1['id'];?>" name="book[]" value="<?php echo $row['id'];?>">
                                        <?php endif ?>
                                        <?php echo $row['title'];?>,
                                            <?php while($w = mysqli_fetch_array($writer)) {
                                                echo $w['firstname'];
                                                echo " ";
                                                echo $w['lastname'];
                                                echo ", ";
                                            }?>
                                            <?php echo $row['version'];?>,
                                            <?php while($w = mysqli_fetch_array($publisher)) {
                                                echo $w['name'];
                                                echo ", ";
                                            }?>
                                            ISBN: <?php echo $row['isbn'];?>
                                        </div>
                                    <?php endwhile;?>
                                </div>
                            <?php endwhile;?>
                        </div>
                    <?php endfor;?>
                </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        function myFunction(id) {
            var x = document.getElementById(id);
            if (x.className.indexOf("w3-show") == -1) {
                x.className += " w3-show";
            } else {
                x.className = x.className.replace(" w3-show", "");
            }
        }
    </script>
    <script>
        function openCity(evt, cityName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";
        }

        // Get the element with id="defaultOpen" and click on it
        document.getElementById("defaultOpen").click();
    </script>
    <script>
        $(document).on('click', 'input[type="checkbox"][data-group]', function(event) {
            // The checkbox that was clicked
            var actor = $(this);
            // The status of that checkbox
            var checked = actor.prop('checked');
            // The group that checkbox is in
            var group =actor.data('group');
            // All checkboxes of that group
            var checkboxes = $('input[type="checkbox"][id="'+ group + '"]');
            // All checkboxes excluding the one that was clicked
            // Check those checkboxes
            checkboxes.prop('checked', checked);
        });
        $(document).on('click', 'input[type="checkbox"][id]', function(event) {
            // The checkbox that was clicked
            var actor = $(this);
            // The status of that checkbox
            var checked = actor.prop('checked');
            // The group that checkbox is in
            var group = actor.attr("id")
            // All checkboxes of that group
            var checkboxes = $('input[type="checkbox"][data-group="' + group + '"]');
            // All checkboxes excluding the one that was clicked
            var otherCheckboxes = checkboxes.not(actor);
            // Check those checkboxes
            if(!checked) {
                otherCheckboxes.prop('checked', checked);
            }
        });
        $("input:checkbox").on('click', function() {
            // in the handler, 'this' refers to the box clicked on
            var $box = $(this);
            if ($box.is(":checked")) {
                // the name of the box is retrieved using the .attr() method
                // as it is assumed and expected to be immutable
                var group = "input:checkbox[data-group='" + $box.attr("data-group") + "']";
                // the checked state of the group/box on the other hand will change
                // and the current value is retrieved using .prop() method
                $(group).prop("checked", false);
                $box.prop("checked", true);
            } else {
                $box.prop("checked", false);
            }
        });
        $(document).on('click', 'input[type="checkbox"][id]', function(event) {
            var checkbox = $(this);
            if (checkbox.is(":checked")) {
                // do the confirmation thing here
                event.preventDefault();
                return false;
            }
        });
    </script>
</body>