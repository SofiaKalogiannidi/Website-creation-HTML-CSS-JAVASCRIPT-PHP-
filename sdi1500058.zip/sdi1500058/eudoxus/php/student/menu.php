<!DOCTYPE html>
<html lang="en">
<head>
    <title>Eudoxus</title>
    <meta charset="utf-8">
    <link href="http://localhost:8080/eudoxus/css/menu.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <script src="http://osvaldas.info/examples/main.js"></script>

    <script src="http://osvaldas.info/examples/drop-down-navigation-touch-friendly-and-responsive/doubletaptogo.js"></script>

    <script>
        $( function()
        {
            $( '#nav li:has(ul)' ).doubleTapToGo();
        });
    </script>
</head>
<body >

<div class="content">
    <nav id="nav" role="navigation"> <a href="#nav" title="Show navigation">Show navigation</a> <a href="#" title="Hide navigation">Hide navigation</a>
        <ul class="clearfix">
            <li><a href="http://localhost:8080/eudoxus/php/student/welcome.php">Στοιχεία Φοιτητή</a></li>
            <li><a href="http://localhost:8080/eudoxus/php/student/book_selection.php">Δηλώσεις Συγγραμάτων</a></li>
            <li><a href="#">Ανταλλαγή Βιβλίων(Εύδοξος+)</a></li>
            <li><a href="http://localhost:8080/eudoxus/php/student/recieving_points.php">Στοιχεία Παραλαβής Συγγραμάτων</a></li>
        </ul>
    </nav>
</div>
<script src="JavaScript/jquery-1.10.2.js" type="text/javascript"></script>

<script type="text/javascript">
    $(function() {
        // this will get the full URL at the address bar
        var url = window.location.href;

        // passes on every "a" tag
        $(".clearfix a").each(function() {
            // checks if its the same on the address bar
            if (url == (this.href)) {
                $(this).closest("li").addClass("active");
                //for making parent of submenu active
                $(this).closest("li").parent().parent().addClass("active");
            }
        });
    });
</script>
</body>
</html>