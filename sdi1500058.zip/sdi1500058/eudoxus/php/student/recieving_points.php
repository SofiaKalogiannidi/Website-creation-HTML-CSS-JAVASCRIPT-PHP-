<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// Store data in session variables
$id=$_SESSION["id"];

// Include config file
require_once "../config.php";

// mysql select query
$query = "SELECT b.* FROM books b,selected_books s where b.id=s.book_id && s.student_id='".$id."'"; //girnao tis plirofories
$result1 = mysqli_query($link, $query);

?>
<!DOCTYPE html>
<head>
    <title>Δήλωση Συγγραμάτων</title>
    <link href="http://localhost:8080/eudoxus/css/columns.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/homepage.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/accordion.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <meta charset="utf-8">
    <style>
        body {
            background-image:url("http://localhost:8080/eudoxus/images/books.jpg");
        }
        .column {
            float: left;
            width: 10%;
            padding: 5px;
        }
        .row:after {
            content: "";
            display: table;
            clear: both;
        }
        .tabcontent:after {
            content: "";
            display: table;
            clear: both;
        }
        #customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: auto;
        }

        #customers td {
            border: 1px solid white;;
            padding: 8px;
        }

        #customers tr:nth-child(even){background-color: white;}

        #customers tr:hover {background-color: white;}

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: center;
            background-color: #e15a1f;
            color: white;
        }
        .w3-btn,.w3-button {
            border: 2px #b3d7ff;
        }
    </style>
</head>
<?php
include "./../../php/header.php";
include ("menu.php");
?>
<body>
<div class="content">
    <div class="panel panel-info">
        <div class="panel-heading">
            Στοιχεία Παραλαβής Συγγραμάτων:
        </div>
        <div class="panel-body">
            <?php while($row = mysqli_fetch_array($result1)):;?>
                <button  type="button" onclick="myFunction('<?php echo $row['id'];?>')" class="w3-btn w3-block w3-black w3-left-align">
                    <?php
                    $sql="SELECT s.* FROM writters s,written w WHERE w.writter_id = s.writter_id and w.book_id = '".$row['id']."'";
                    $writer= mysqli_query($link,$sql);
                    $sql="SELECT p.name FROM books b,publisher p WHERE b.publisher_id = p.id and b.id = '".$row['id']."'";
                    $publisher= mysqli_query($link,$sql);
                    ?>
                    <?php echo $row['title'];?>,
                    <?php while($w = mysqli_fetch_array($writer)) {
                        echo $w['firstname'];
                        echo " ";
                        echo $w['lastname'];
                        echo ", ";
                    }?>
                    <?php echo $row['version'];?>,
                    <?php while($w = mysqli_fetch_array($publisher)) {
                        echo $w['name'];
                        echo ", ";
                    }?>
                    ISBN: <?php echo $row['isbn'];?>
                </button>
                <div id="<?php echo $row['id'];?>" class="w3-container w3-hide" style="text-align: center;padding:2%">
                    <?php
                    $sql="SELECT p.* FROM distribution_point p,distribution d WHERE d.point_id=p.id and d.book_id = '".$row['id']."'";
                    $d= mysqli_query($link,$sql);
                    $d = mysqli_fetch_array($d)
                    ?>
                    <table id="customers" >
                        <tr>
                            <th><?php echo $d['name'];?></th>
                            <th></th>
                        </tr>
                        <tr>
                            <td style="font-weight: bold;">Διεύθυνση</td>
                            <td><?php echo $d['address'];?></td>
                        </tr>
                        <tr>
                            <td style="font-weight: bold;">Email</td>
                            <td><?php echo $d['email'];?></td>
                        </tr>
                        <tr>
                            <td style="font-weight: bold;">Σταθερό Τηλέφωνο</td>
                            <td><?php echo $d['phone_number'];?></td>
                        </tr>
                        <tr>
                            <td style="font-weight: bold;">"Ώρες Λειτουργίας"</td>
                            <td><?php echo $d['open_time'];?></td>
                        </tr>
                    </table>
                </div>
            <?php endwhile;?>
        </div>
    </div>
</div>
        <script>
            function myFunction(id) {
                var x = document.getElementById(id);
                if (x.className.indexOf("w3-show") == -1) {
                    x.className += " w3-show";
                } else {
                    x.className = x.className.replace(" w3-show", "");
                }
            }
        </script>
</body>