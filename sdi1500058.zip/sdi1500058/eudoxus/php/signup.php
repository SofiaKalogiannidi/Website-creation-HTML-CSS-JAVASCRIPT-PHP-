</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <link href="http://localhost:8080/eudoxus/css/columns.css" rel="stylesheet" type="text/css">
    <link href="http://localhost:8080/eudoxus/css/homepage.css" rel="stylesheet" type="text/css">  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Add icon library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        * {box-sizing: border-box}
        body {font-family: "Lato", sans-serif;}

        /* Style the tab */
        .tab {
            float: left;
            border: 1px solid #b3d7ff;
            background-color: white;
            width: 20%;
            /*height: 300px;*/
        }

        /* Style the buttons inside the tab */
        .tab button {
            display: block;
            background-color: inherit;
            color: #CF4623;
            padding: 22px 16px;
            width: 100%;
            border: none;
            outline: none;
            text-align: left;
            cursor: pointer;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */
        .tab button:hover {
            background-color: #b3d7ff;
        }

        /* Create an active/current "tab button" class */
        .tab button.active {
            background-color: #b3d7ff;
        }

        /* Style the tab content */
        .tabcontent {
            float: left;
            padding: 0px 12px;
            border: 1px solid white;
            width: 80%;
            /*height: 300px;*/
        }

        .input-containerf {
            display: -ms-flexbox; /* IE10 */
            display: flex;
            width: 100%;
            margin-bottom: 15px;
        }

        .iconf {
            padding: 10px;
            background: #b3d7ff;
            color: white;
            min-width: 50px;
            text-align: center;
        }

        .input-fieldf ,select{
            width: 100%;
            padding: 10px;
            outline: none;
            border: 2px solid #b3d7ff;
        }

        .input-fieldf:focus,select:focus {
            border: 2px solid orange;
        }

        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        /* Set a style for the submit button */
        .btnf {
            background-color: #b3d7ff;
            color: white;
            padding: 15px 20px;
            border: none;
            cursor: pointer;
            width: 100%;
            opacity: 0.9;
        }

        .btnf:hover {
            opacity: 1;
        }

        .ccontainer {
            display: block;
            position: relative;
            padding-left: 35px;
            margin-bottom: 12px;
            cursor: pointer;
            font-size: 22px;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        /* Hide the browser's default checkbox */
        .ccontainer input {
            position: absolute;
            opacity: 0;
            cursor: pointer;
            height: 0;
            width: 0;
        }

        /* Create a custom checkbox */
        .ccheckmark {
            position: absolute;
            top: 0;
            left: 0;
            height: 25px;
            width: 25px;
            background-color: #eee;
        }

        /* On mouse-over, add a grey background color */
        .ccontainer:hover input ~ .ccheckmark {
            background-color: #ccc;
        }

        /* When the checkbox is checked, add a blue background */
        .ccontainer input:checked ~ .ccheckmark {
            background-color: #b3d7ff;
        }

        /* Create the checkmark/indicator (hidden when not checked) */
        .ccheckmark:after {
            content: "";
            position: absolute;
            display: none;
        }

        /* Show the checkmark when checked */
        .ccontainer input:checked ~ .ccheckmark:after {
            display: block;
        }

        /* Style the checkmark/indicator */
        .ccontainer .ccheckmark:after {
            left: 9px;
            top: 5px;
            width: 5px;
            height: 10px;
            border: solid white;
            border-width: 0 3px 3px 0;
            -webkit-transform: rotate(45deg);
            -ms-transform: rotate(45deg);
            transform: rotate(45deg);
        }

    </style>
</head>
<body style="background:#E48400 ">
<?php
include "./header.php";
include "./menu.php";
?>
<div class="content">
    <div class="panel panel-info">
        <div class="panel-heading">
        </div>
        <div class="panel-body">
            <div class="tab">
                <button class="tablinks" onclick="openCity(event, 'Φοιτητές')" id="defaultOpen">Φοιτητές</button>
                <button class="tablinks" onclick="openCity(event, 'Εκδότες')">Εκδότες</button>
            </div>
            <div id="Φοιτητές" class="tabcontent">
                <form action="signupSavetodb.php" style="max-width:500px;margin:auto" id="student" method="get">
                    <h4 style="color:#CF4623">Συμπληρώστε τα στοιχεία σας:</h4>

                    <input type="hidden" id="who" name="who" value="1">

                    <div class="input-containerf">
                        <i class="fa fa-user iconf"></i>
                        <input class="input-fieldf" type="text" required placeholder="Όνομα" name="name"  maxlength="45">
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-user iconf"></i>
                        <input class="input-fieldf" type="text" required placeholder="Επώνυμο" name="lastname" maxlength="45">
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-user iconf"></i>
                        <input class="input-fieldf" type="text" required placeholder="Όνομα Χρήστη" name="usrnm" id="usrnm1" maxlength="45">
                        <div style="padding-bottom:10px" id='uname_response1'><p> </p></div>
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-envelope iconf"></i>
                        <input class="input-fieldf" type="email" required placeholder="E-mail Σχολής" name="email" id="email1" maxlength="45">
                        <div style="padding-bottom:10px" id='email_response1'><p> </p></div>
                    </div>

                    <div class="input-containerf">
                        <i style="background:" class="fa fa-key iconf"></i>
                        <input class="input-fieldf" type="password" required placeholder="Κωδικός" name="psw" id="psw" maxlength="45">
                    </div>

                    <div class="input-containerf">
                        <i style="background:" class="fa fa-key iconf"></i>
                        <input class="input-fieldf" type="password" required placeholder="Επιβεβαίωση Κωδικού" name="psw2" id="psw2" maxlength="45">
                    </div>

                    <div style="padding-bottom:10px" id='message'></div>

                    <div class="input-containerf">
                        <i class="fa fa-id-badge iconf"></i>
                        <input class="input-fieldf" type="number" min="0" required placeholder="Αριθμός Μητρώου" name="am" max="99999999999999999999">
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-graduation-cap iconf"></i>
                        <select id="dep" class="input-fieldf" name="dep" form="student">
                            <option value="1">ΤΜΗΜΑ ΑΓΓΛΙΚΗΣ ΓΛΩΣΣΑΣ ΚΑΙ ΦΙΛΟΛΟΓΙΑΣ</option>
                            <option value="2">ΤΜΗΜΑ ΒΙΟΛΟΓΙΑΣ</option>
                            <option value="3">ΤΜΗΜΑ ΘΕΟΛΟΓΙΑΣ</option>
                            <option value="5">ΤΜΗΜΑ ΜΑΘΗΜΑΤΙΚΩΝ</option>
                            <option value="5">ΤΜΗΜΑ ΠΑΙΔΑΓΩΓΙΚΟΥ ΔΗΜΟΤΙΚΗΣ ΕΚΠΑΙΔΕΥΣΗΣ</option>
                            <option value="4">ΤΜΗΜΑ ΠΛΗΡΟΦΟΡΙΚΗΣ ΚΑΙ ΤΗΛΕΠΙΚΟΙΝΩΝΙΩΝ</option>
                            <option value="7">ΤΜΗΜΑ ΦΑΡΜΑΚΕΥΤΙΚΗΣ</option>
                            <option value="8">ΤΜΗΜΑ ΦΥΣΙΚΗΣ</option>
                            <option value="6">ΤΜΗΜΑ ΧΗΜΕΙΑΣ</option>
                        </select>
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-graduation-cap iconf"></i>
                        <select id="inst" class="input-fieldf" name="inst" form="student">
                            <option value="1">ΕΠΙΣΤΗΜΩΝ ΑΓΩΓΗΣ</option>
                            <option value="2">ΕΠΙΣΤΗΜΩΝ ΥΓΕΙΑΣ</option>
                            <option value="3">ΕΠΙΣΤΗΜΗΣ ΦΥΣΙΚΗΣ ΑΓΩΓΗΣ ΚΑΙ ΑΘΛΗΤΙΣΜΟΥ</option>
                            <option value="4">ΘΕΟΛΟΓΙΚΗ</option>
                            <option value="5">ΘΕΤΙΚΩΝ ΕΠΙΣΤΗΜΩΝ</option>
                            <option value="6">ΝΟΜΙΚΗ</option>
                            <option value="7">ΟΙΚΟΝΟΜΙΚΩΝ ΚΑΙ ΠΟΛΙΤΙΚΩΝ ΕΠΙΣΤΗΜΩΝ</option>
                            <option value="8">ΦΙΛΟΣΟΦΙΚΗ</option>
                        </select>
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-institution iconf"></i>
                        <select id="uni" class="input-fieldf" name="uni" form="student">
                            <option value="1">Ανωτάτη Σχολή Καλών Τεχνών</option>
                            <option value="2"> Αριστοτέλειο Πανεπιστήμιο Θεσσαλονίκης</option>
                            <option value="3">Γεωπονικό Πανεπιστήμιο Αθηνών</option>
                            <option value="4">Εθνικό και Καποδιστριακό Πανεπιστήμιο Αθηνών</option>
                            <option value="5">Εθνικό Μετσόβιο Πoλυτεχνείο</option>
                            <option value="6">Οικονομικό Πανεπιστήμιο Αθηνών</option>
                            <option value="7">Πανεπιστήμιο Κρήτης</option>
                            <option value="8">Πανεπιστήμιο Πειραιά</option>
                        </select>
                    </div>

                    <button type="submit" class="btnf">Εγγραφή</button>
                </form>
            </div>

            <div id="Εκδότες" class="tabcontent">
                <form action="signupSavetodb.php" style="max-width:500px;margin:auto" id="editor" method="get">
                    <h4 style="color:#CF4623">Συμπληρώστε τα στοιχεία σας:</h4>

                    <h5 style="color:#CF4623">Αυτοέκδοση:</h5>


                    <label class="ccontainer"> Ναι
                        <input type="checkbox" id="myCheck" value="value1" name="check"  onclick="myFunction()">
                        <span class="ccheckmark"></span>
                    </label>

                    <input type="hidden" id="who" name="who" value="2">

                    <div id="rest1">
                        <div  class="input-containerf">
                            <i class="fa fa-user iconf"></i>
                            <input class="input-fieldf" type="text" placeholder="Επωνυμία " name="name" maxlength="45">
                        </div>
                    </div>

                    <div style="display:none;" id="rest2">
                        <div class="input-containerf">
                            <i class="fa fa-user iconf"></i>
                            <input class="input-fieldf" type="text" placeholder="Όνομα " name="name" maxlength="45">
                        </div>

                        <div class="input-containerf">
                            <i class="fa fa-user iconf"></i>
                            <input class="input-fieldf" type="text" placeholder="Επώνυμο" name="lastname" maxlength="45">
                        </div>
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-envelope iconf"></i>
                        <input class="input-fieldf" type="email" required placeholder="E-mail" name="email" id="email" maxlength="45">
                        <div style="padding-bottom:10px" id='email_response'><p> </p></div>
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-user iconf"></i>
                        <input class="input-fieldf" type="text" required placeholder="Όνομα Χρήστη" name="usrnm" id="usrnm" maxlength="45">
                        <div style="padding-bottom:10px" id='uname_response'><p> </p></div>
                    </div>

                    <div class="input-containerf">
                        <i style="background:" class="fa fa-key iconf"></i>
                        <input class="input-fieldf" type="password" required placeholder="Κωδικός" name="epsw" id="epsw" maxlength="45">
                    </div>

                    <div class="input-containerf">
                        <i style="background:" class="fa fa-key iconf"></i>
                        <input class="input-fieldf" type="password" required placeholder="Επιβεβαίωση Κωδικού" name="epsw2" id="epsw2" maxlength="45">
                    </div>

                    <div style="padding-bottom:10px" id='emessage'></div>

                    <div class="input-containerf">
                        <i class="fa fa-user iconf"></i>
                        <input class="input-fieldf" type="number" required placeholder="Α.Φ.Μ." name="afm" max="9999999999">
                    </div>


                    <div class="input-containerf">
                        <i class="fa fa-graduation-cap iconf"></i>
                        <select id="doi" class="input-fieldf" name="doi" form="editor">
                            <option value="1">Δ.Ο.Υ. ΑΓΙΑΣ ΠΑΡΑΣΚΕΥΗΣ </option>
                            <option value="2">Δ.Ο.Υ. ΑΘΗΝΩΝ Α</option>
                            <option value="3">Δ.Ο.Υ. ΑΘΗΝΩΝ Β</option>
                            <option value="5">Δ.Ο.Υ. ΑΘΗΝΩΝ Γ</option>
                            <option value="5">Δ.Ο.Υ. ΠΑΛΛΗΝΗΣ</option>
                        </select>
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-phone iconf"></i>
                        <input class="input-fieldf" type="number" required placeholder="Σταθερό Τηλέφωνο" name="phone1" max="999999999999">
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-mobile iconf"></i>
                        <input class="input-fieldf" type="number" min="0" required placeholder="Κινητό Τηλέφωνο" name="phone2" max="999999999999">
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-fax iconf"></i>
                        <input class="input-fieldf" type="number" min="0" required placeholder="FAX" name="fax" max="999999999999">
                    </div>


                    <div class="input-containerf">
                        <i class="fa fa-home iconf"></i>
                        <input class="input-fieldf" type="text" required placeholder="Διεύθυνση" name="adress" maxlength="45">
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-map-marker iconf"></i>
                        <input class="input-fieldf" type="number" required placeholder="Ταχυδρομικός Κώδικας" name="tk" max="99999">
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-map-marker iconf"></i>
                        <input class="input-fieldf" type="text" required placeholder="Πόλη" name="town" maxlength="45">
                    </div>

                    <div class="input-containerf">
                        <i class="fa fa-globe iconf"></i>
                        <input class="input-fieldf" type="text" required placeholder="Χώρα" name="country" maxlength="45">
                    </div>

                    <div id="rest">
                        <h4 style="color:#CF4623">Συμπληρώστε τα Στοιχεία Υπευθύνου:</h4>

                        <div class="input-containerf">
                            <i class="fa fa-user iconf"></i>
                            <input class="input-fieldf" type="text" placeholder="Όνομα" name="name2" maxlength="45">
                        </div>


                        <div class="input-containerf">
                            <i class="fa fa-user iconf"></i>
                            <input class="input-fieldf" type="text" placeholder="Επώνυμο" name="name3" maxlength="45">
                        </div>

                        <div class="input-containerf">
                            <i class="fa fa-envelope iconf"></i>
                            <input class="input-fieldf" type="email" placeholder="E-mail" name="email2" id="email2" maxlength="45">
                            <div style="padding-bottom:10px" id='email_response2'><p> </p></div>
                        </div>

                        <div class="input-containerf">
                            <i class="fa fa-phone iconf"></i>
                            <input class="input-fieldf" type="number" placeholder="Σταθερό Τηλέφωνο" name="phone3" max="999999999999">
                        </div>

                    </div>

                    <button type="submit" class="btnf">Εγγραφή</button>
                </form>
            </div>

        </div>
    </div>


</div>


<script>
    function openCity(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }

    $('#psw, #psw2').on('keyup', function () {
        if ($('#psw').val() == $('#psw2').val()) {
            $('#message').html('Passwords Matching').css('color', 'green');
        } else
            $('#message').html('Passwords not Matching').css('color', 'red');
    });

    $('#epsw, #epsw2').on('keyup', function () {
        if ($('#epsw').val() == $('#epsw2').val()) {
            $('#emessage').html('Passwords Matching').css('color', 'green');
        } else
            $('#emessage').html('Passwords not Matching').css('color', 'red');
    });

    function myFunction() {
        var checkBox = document.getElementById("myCheck");
        var text = document.getElementById("rest");
        var text1 = document.getElementById("rest1");
        var text2 = document.getElementById("rest2");
        if (checkBox.checked == true){
            text.style.display = "none";
            text1.style.display = "none";
            text2.style.display = "block";
        } else {
            text.style.display = "block";
            text1.style.display = "block";
            text2.style.display = "none";
        }
    }

    $(document).ready(function(){

        $("#usrnm").keyup(function(){

            var uname = $("#usrnm").val().trim();

            if(uname != ''){

                $("#uname_response").show();

                $.ajax({
                    url: 'check/checkusername.php',
                    type: 'post',
                    data: {uname:uname},
                    success: function(response){

                        if(response > 0){
                            $("#uname_response").html('Όνομα χρήστη μη διαθέσιμο').css('color', 'red');
                        }else{
                            $("#uname_response").html('Όνομα χρήστη διαθέσιμο').css('color', 'green');
                        }

                    }
                });
            }else{
                $("#uname_response").hide();
            }

        });

    });

    $(document).ready(function(){

        $("#usrnm1").keyup(function(){

            var uname = $("#usrnm1").val().trim();

            if(uname != ''){

                $("#uname_response1").show();

                $.ajax({
                    url: 'check/checkusername.php',
                    type: 'post',
                    data: {uname:uname},
                    success: function(response){

                        if(response > 0){
                            $("#uname_response1").html('Όνομα χρήστη μη διαθέσιμο').css('color', 'red');
                        }else{
                            $("#uname_response1").html('Όνομα χρήστη διαθέσιμο').css('color', 'green');
                        }

                    }
                });
            }else{
                $("#uname_response1").hide();
            }

        });

    });


    $(document).ready(function(){

        $("#email1").keyup(function(){

            var uname = $("#email1").val().trim();

            if(uname != ''){

                $("#email_response1").show();

                $.ajax({
                    url: 'check/checkemail.php',
                    type: 'post',
                    data: {uname:uname},
                    success: function(response){

                        if(response > 0){
                            $("#email_response1").html('E-mail μη διαθέσιμο').css('color', 'red');
                        }else{
                            $("#email_response1").html('E-mail χρήστη διαθέσιμο').css('color', 'green');
                        }

                    }
                });
            }else{
                $("#email_response1").hide();
            }

        });

    });

    $(document).ready(function(){

        $("#email").keyup(function(){

            var uname = $("#email").val().trim();

            if(uname != ''){

                $("#email_response").show();

                $.ajax({
                    url: 'check/checkemail.php',
                    type: 'post',
                    data: {uname:uname},
                    success: function(response){

                        if(response > 0){
                            $("#email_response").html('E-mail μη διαθέσιμο').css('color', 'red');
                        }else{
                            $("#email_response").html('E-mail χρήστη διαθέσιμο').css('color', 'green');
                        }

                    }
                });
            }else{
                $("#email_response").hide();
            }

        });

    });

    $(document).ready(function(){

        $("#email2").keyup(function(){

            var uname = $("#email2").val().trim();

            if(uname != ''){

                $("#email_response2").show();

                $.ajax({
                    url: 'check/checkemail.php',
                    type: 'post',
                    data: {uname:uname},
                    success: function(response){

                        if(response > 0){
                            $("#email_response2").html('E-mail μη διαθέσιμο').css('color', 'red');
                        }else{
                            $("#email_response2").html('E-mail χρήστη διαθέσιμο').css('color', 'green');
                        }

                    }
                });
            }else{
                $("#email_response2").hide();
            }

        });

    });

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();
</script>
</body>