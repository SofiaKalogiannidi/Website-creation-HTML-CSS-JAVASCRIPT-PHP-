<!DOCTYPE html>
<html lang="en">
<head>

    <link href="http://localhost:8080/eudoxus/css/columns.css" rel="stylesheet" type="text/css">
    <style>

        .boxed {
            border: 3px solid #e15a1f ;
            font-family:Arial,Helvetica;
        }
    </style>


        </head>
<body>
<?php
include "header.php";
include "../php/menu.php";
?>
<div class="content">



    <div class="panel panel-info" style="width:auto">

        <div class="panel-heading">
            <h2 style="color:#1F77CF;font-family:Arial,Helvetica"> Βοήθεια <i class="glyphicon glyphicon-question-sign"></i></h2>
        </div>
        <div class="panel-body">
            <h2 style="color:#1F77CF;font-family:Arial,Helvetica"> Eπικοινωνία (Γραφείο Αρωγής) </h2>

            <p ><b>Μπορείτε να επικοινωνήσετε με το Γραφείο Αρωγής
                    της δράσης στο τηλέφωνο 215 215 7850.</b></p>
            <h2 style="color:#1F77CF;font-family:Arial,Helvetica">Ωρες λειτουργίας</h2>
            <p ><b>Ώρες λειτουργίας Δευτέρα με Παρασκευή 09:00 πμ - 17:00 μμ</b></p>


        </div>
    </div>




</div>
</body>

</html>