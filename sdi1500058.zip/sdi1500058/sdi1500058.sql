-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Φιλοξενητής: 127.0.0.1
-- Χρόνος δημιουργίας: 14 Ιαν 2019 στις 22:07:25
-- Έκδοση διακομιστή: 10.1.37-MariaDB
-- Έκδοση PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `sdi1500058`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(500) CHARACTER SET greek NOT NULL,
  `version` varchar(200) CHARACTER SET greek NOT NULL,
  `isbn` varchar(25) CHARACTER SET greek DEFAULT NULL,
  `publisher_id` int(11) NOT NULL,
  `image` varchar(500) CHARACTER SET greek DEFAULT NULL,
  `book_type` varchar(10) DEFAULT NULL,
  `active` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `books`
--

INSERT INTO `books` (`id`, `title`, `version`, `isbn`, `publisher_id`, `image`, `book_type`, `active`) VALUES
(2, 'C: Από τη Θεωρία στην Εφαρμογή', '2013', '978-960-93-1961-4', 2, 'http://localhost:8080/eudoxus/images/book1.jpg', 'book', 1),
(3, 'Η ΓΛΩΣΣΑ ΠΡΟΓΡΑΜΜΑΤΙΣΜΟΥ C', '2008', '978-960-46-1132-4', 1, 'http://localhost:8080/eudoxus/images/book2.jpg', 'book', 1),
(4, 'ΛΕΙΤΟΥΡΓΙΚΑ ΣΥΣΤΗΜΑΤΑ', '2013', '978-960-51-2651-3', 3, 'http://localhost:8080/eudoxus/images/book3.jpg', 'book', 1),
(5, 'ΔΙΑΚΡΙΤΑ ΜΑΘΗΜΑΤΙΚΑ ΜΕ ΕΦΑΡΜΟΓΕΣ', '2013', '978-960-461-325-0', 1, 'http://localhost:8080/eudoxus/images/book4.jpg', 'e-book', 1);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET greek NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `department`
--

INSERT INTO `department` (`id`, `name`) VALUES
(4, 'Τμήμα Πληροφορικής και Τηλεπικοινωνιών'),
(5, 'Τμήμα Μαθηματικών'),
(6, 'Τμήμα Ψυχολογίας');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `distribution`
--

CREATE TABLE `distribution` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `point_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `distribution`
--

INSERT INTO `distribution` (`id`, `book_id`, `point_id`) VALUES
(1, 2, 1),
(2, 3, 2),
(3, 4, 3),
(4, 5, 2);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `distribution_point`
--

CREATE TABLE `distribution_point` (
  `id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET greek DEFAULT NULL,
  `address` varchar(200) CHARACTER SET greek DEFAULT NULL,
  `phone_number` varchar(15) CHARACTER SET greek DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `open_time` varchar(100) CHARACTER SET greek NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `distribution_point`
--

INSERT INTO `distribution_point` (`id`, `name`, `address`, `phone_number`, `email`, `open_time`) VALUES
(1, 'ΒΙΒΛΙΟΠΩΛΕΙΟ ΕΝΑΣΤΡΟΝ', 'ΣΟΛΩΝΟΣ 101', '2103828161', 'enastro@gmail.com', 'Καθημερινά, 9πμ-13.μμ'),
(2, 'ΒΙΒΛΙΟΠΩΛΕΙΟ ΕΚΔΟΣΕΙΣ ΚΛΕΙΔΑΡΙΘΜΟΣ', 'ΑΚΑΔΗΜΙΑΣ 42', '2103642887', 'kleidarithmos50@gmail.com', 'Καθημερινά, 9πμ-14.μμ'),
(3, 'Μ.ΓΚΙΟΥΡΔΑΣ', 'ΣΕΡΓΙΟΥ ΠΑΤΡΙΑΡΧΟΥ 4', '2103624947', 'giourdas@hotmail.com', 'Δε-Τε-Πα, 10πμ-16.μμ');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `publisher`
--

CREATE TABLE `publisher` (
  `id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET greek NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `AFM` varchar(10) DEFAULT NULL,
  `DOI` varchar(50) CHARACTER SET greek DEFAULT NULL,
  `phone` varchar(12) NOT NULL,
  `mob_phone` varchar(12) DEFAULT NULL,
  `fax` varchar(12) DEFAULT NULL,
  `address` varchar(50) CHARACTER SET greek DEFAULT NULL,
  `postal_code` varchar(5) DEFAULT NULL,
  `country` varchar(50) CHARACTER SET greek DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `phone_user` varchar(12) DEFAULT NULL,
  `town` varchar(50) CHARACTER SET greek DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `publisher`
--

INSERT INTO `publisher` (`id`, `name`, `email`, `AFM`, `DOI`, `phone`, `mob_phone`, `fax`, `address`, `postal_code`, `country`, `user_id`, `phone_user`, `town`) VALUES
(1, 'ΕΚΔΟΣΕΙΣ ΚΛΕΙΔΑΡΙΘΜΟΣ ΕΠΕ', 'kleidarithmos@gmail.com', '1111111111', 'Δ.Ο.Υ. ΑΘΗΝΩΝ Α', '2106052447', '6989455561', '2106052447', 'Σταδίου 5', '19007', 'Ελλάδα', 8, '6959241516', 'Αθήνα'),
(2, 'Γ.Σ.ΤΣΕΛΙΚΗΣ, Ν.Δ.ΤΣΕΛΙΚΑΣ', 'Tselikas-tselikas@gmail.com', '2222222222', 'Δ.Ο.Υ. ΑΘΗΝΩΝ B', '2224558933', '6972730405', '2224558933', 'Ιπποκράτους 139', '19006', 'Ελλάδα', 9, '6948496521', 'Αθήνα'),
(3, 'Χ.ΓΚΙΟΥΡΔΑ', 'giouedas@hotmail.com', '3333333333', 'Δ.Ο.Υ. ΑΘΗΝΩΝ Γ', '2219578452', '6959241719', '2219578452', 'Σοφοκλέους 26', '19574', 'Ελλάδα', 10, '6978762531', 'Αθήνα');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `selected_books`
--

CREATE TABLE `selected_books` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `selected_books`
--

INSERT INTO `selected_books` (`id`, `student_id`, `book_id`, `subject_id`) VALUES
(0, 1, 5, 2),
(0, 1, 2, 4);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `am` varchar(45) CHARACTER SET greek NOT NULL,
  `institution` varchar(45) CHARACTER SET greek NOT NULL,
  `universtity` varchar(45) CHARACTER SET greek NOT NULL,
  `user_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `students`
--

INSERT INTO `students` (`student_id`, `am`, `institution`, `universtity`, `user_id`, `department_id`) VALUES
(1, '12423', 'rtr', 'tr', 1, 4),
(2, '1115201500051', 'Σχολή Θετικών Επιστημών', 'Εθνικό και Καποδιστριακό Πανεπιστήμιο Αθηνών', 5, 4),
(3, '1115201500058', 'Σχολή Θετικών Επιστημών', 'Εθνικό και Καποδιστριακό Πανεπιστήμιο Αθηνών', 7, 4),
(4, '1115201500038', 'Σχολή Θετικών Επιστημών', 'Εθνικό και Καποδιστριακό Πανεπιστήμιο Αθηνών', 6, 4);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `name` varchar(200) CHARACTER SET greek DEFAULT NULL,
  `semester` int(11) DEFAULT NULL,
  `proffesor` varchar(30) CHARACTER SET greek DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `subject`
--

INSERT INTO `subject` (`id`, `name`, `semester`, `proffesor`) VALUES
(1, 'ΓΡΑΜΙΚΗ ΑΛΓΕΥΡΑ', 1, 'Ε. ΡΑΠΤΗΣ'),
(2, 'ΔΙΑΚΡΙΤΑ ΜΑΘΗΜΑΤΙΚΑ', 1, 'Ι. ΕΜΙΡΗΣ, Ο. ΦΟΥΡΤΟΥΝΕΛΛΗ'),
(3, 'ΕΙΣΑΓΩΓΗ ΣΤΗΝ ΠΛΗΡΟΦΟΡΙΚΗ ΚΑΙ ΣΤΙΣ ΤΗΛΕΠΙΚΟΙΝΩΝΙΕΣ', 1, 'Α. ΤΣΑΛΓΑΤΙΔΟΥ'),
(4, 'ΕΙΣΑΓΩΓΗ ΣΤΟΝ ΠΡΟΓΡΑΜΜΑΤΙΣΜΟ', 1, 'Π. ΣΤΑΜΑΤΟΠΟΥΛΟΣ'),
(5, 'ΛΟΓΙΚΗ ΣΧΕΔΙΑΣΗ', 1, 'Α. ΠΑΣΧΑΛΗΣ'),
(6, 'ΕΡΓΑΣΤΗΡΙΟ ΛΟΓΙΚΗΣ ΣΧΕΔΙΑΣΗΣ', 1, 'Α. ΠΑΣΧΑΛΗΣ'),
(7, 'ΑΝΑΛΥΣΗ 2', 3, 'Ε. ΚΟΤΤΑ-ΑΘΑΝΑΣΙΑΔΟΥ'),
(8, 'ΑΝΤΙΚΕΙΜΕΝΟΣΤΡΑΦΗΣ ΠΡΟΓΡΑΜΑΤΙΣΜΟΣ', 3, '	Ι. ΚΑΡΑΛΗ, Σ. ΞΕΡΓΙΑΣ'),
(9, 'ΛΕΙΤΟΥΡΓΙΚΑ ΣΥΣΤΗΜΑΤΑ', 5, 'Α. ΔΕΛΗΣ, Ε. ΧΑΤΖΗΕΥΘΥΜΙΑΔΗΣ'),
(10, 'ΕΠΙΚΟΙΝΩΝΙΑ ΑΝΘΡΩΠΟΥ ΜΗΧΑΝΗΣ', 7, 'Μ. ΡΟΥΣΣΟΥ');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `subject_books`
--

CREATE TABLE `subject_books` (
  `id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `subject_books`
--

INSERT INTO `subject_books` (`id`, `subject_id`, `book_id`) VALUES
(1, 4, 2),
(2, 4, 3),
(3, 9, 4),
(4, 2, 5);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `university_subject`
--

CREATE TABLE `university_subject` (
  `id` int(11) NOT NULL,
  `uni_id` int(11) NOT NULL,
  `sub_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `university_subject`
--

INSERT INTO `university_subject` (`id`, `uni_id`, `sub_id`) VALUES
(1, 4, 1),
(2, 4, 2),
(3, 4, 3),
(4, 4, 4),
(5, 4, 5),
(6, 4, 6),
(7, 4, 7),
(8, 4, 8),
(9, 4, 9),
(10, 4, 10);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(45) CHARACTER SET greek NOT NULL,
  `lastname` varchar(45) CHARACTER SET greek NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `email`, `password`, `username`) VALUES
(1, 'e', 'e', 'e', 'j', 'e'),
(5, 'Σοφία', 'Καζαντζίδου', 'sdi1500051@di.uoa.gr', 'j', 'sdi1500051'),
(6, 'Ευστρατία', 'Ευαγγελινού', 'sdi1500038@di.uoa.gr', 'j', 'sdi1500038'),
(7, 'Σοφία', 'Καλογιαννίδη', 'sdi1500058@di.uoa.gr', 'j', 'sdi1500058'),
(8, 'Μαρία', 'Μάρκου', 'mary6666@gmail.com', 'j', 'ddd'),
(9, 'Παύλος', 'Μάρκου', 'paul56@gmail.gr', 'j', 'paulos'),
(10, 'Νικολέτα', 'Παπαδοπούλου', 'nik@gmail.com', 'a', 'q');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `written`
--

CREATE TABLE `written` (
  `written_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `writter_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `written`
--

INSERT INTO `written` (`written_id`, `book_id`, `writter_id`) VALUES
(5, 2, 5),
(6, 2, 6),
(7, 3, 7),
(8, 3, 8),
(9, 4, 9),
(10, 5, 10);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `writters`
--

CREATE TABLE `writters` (
  `writter_id` int(11) NOT NULL,
  `firstname` varchar(45) CHARACTER SET greek NOT NULL,
  `lastname` varchar(45) CHARACTER SET greek NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `writters`
--

INSERT INTO `writters` (`writter_id`, `firstname`, `lastname`) VALUES
(1, 'Paul', 'Green'),
(2, 'Peter', 'Brown'),
(3, 'Park', 'Jimin'),
(4, 'Jeon', 'Yionkook'),
(5, 'Γ.Σ.', 'ΤΣΕΛΙΚΗΣ'),
(6, 'Ν.Δ.', 'ΤΣΕΛΙΚΑΣ'),
(7, 'BRIAN W.', 'KERNIGHAN'),
(8, 'DENNIS M.', 'RITCHIE'),
(9, 'ABRAHAM', 'SILBERSCHATZ'),
(10, 'Sussana S.', 'Epp');

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `books_id_uindex` (`id`);

--
-- Ευρετήρια για πίνακα `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `department_id_uindex` (`id`);

--
-- Ευρετήρια για πίνακα `distribution`
--
ALTER TABLE `distribution`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `distribution_id_uindex` (`id`);

--
-- Ευρετήρια για πίνακα `distribution_point`
--
ALTER TABLE `distribution_point`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `distribution_point_id_uindex` (`id`);

--
-- Ευρετήρια για πίνακα `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `publisher_id_uindex` (`id`);

--
-- Ευρετήρια για πίνακα `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `students_department_id_fk` (`department_id`);

--
-- Ευρετήρια για πίνακα `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Ευρετήρια για πίνακα `subject_books`
--
ALTER TABLE `subject_books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subject_books_id_uindex` (`id`);

--
-- Ευρετήρια για πίνακα `university_subject`
--
ALTER TABLE `university_subject`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `university_subject_id_uindex` (`id`);

--
-- Ευρετήρια για πίνακα `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Ευρετήρια για πίνακα `written`
--
ALTER TABLE `written`
  ADD PRIMARY KEY (`written_id`),
  ADD UNIQUE KEY `written_written_id_uindex` (`written_id`),
  ADD KEY `writter_id` (`writter_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Ευρετήρια για πίνακα `writters`
--
ALTER TABLE `writters`
  ADD PRIMARY KEY (`writter_id`),
  ADD UNIQUE KEY `writters_writter_id_uindex` (`writter_id`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT για πίνακα `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT για πίνακα `distribution`
--
ALTER TABLE `distribution`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT για πίνακα `distribution_point`
--
ALTER TABLE `distribution_point`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT για πίνακα `publisher`
--
ALTER TABLE `publisher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT για πίνακα `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT για πίνακα `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT για πίνακα `subject_books`
--
ALTER TABLE `subject_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT για πίνακα `university_subject`
--
ALTER TABLE `university_subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT για πίνακα `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT για πίνακα `written`
--
ALTER TABLE `written`
  MODIFY `written_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT για πίνακα `writters`
--
ALTER TABLE `writters`
  MODIFY `writter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Περιορισμοί για άχρηστους πίνακες
--

--
-- Περιορισμοί για πίνακα `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_department_id_fk` FOREIGN KEY (`department_id`) REFERENCES `department` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
